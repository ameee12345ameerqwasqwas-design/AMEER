<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .game-container { max-height:400px; overflow-y:auto; padding-right:8px; }
      .game-row { display:flex; align-items:center; gap:10px; margin-bottom:10px; }
  </style>

<div class="row justify-content-center mt-4">
    <div class="col-lg-9">
        <?= $this->include('Layout/msgStatus') ?>
        
        <div class="card shadow-sm animate-in">
            <div class="card-header text-white">
                <i class="bi bi-pencil-square me-2"></i> Edit Bot
            </div>
            <div class="card-body">
                <form action="<?= site_url('bots/update/' . $bot['id']) ?>" method="post">
                    <?= csrf_field() ?>
                    
                    <div class="mb-4">
                        <label class="form-label">Bot Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" 
                               value="<?= esc($bot['name']) ?>" required>
                    </div>

                    <!-- Registrator -->
                    <div class="mb-4">
                        <label class="form-label">Registrator <span class="text-danger">*</span></label>
                        <input type="text" name="registrator" class="form-control" 
                               value="<?= esc($bot['registrator'] ?? '') ?>" required>
                        <small class="text-muted">This name will be recorded in all keys generated from this bot</small>
                    </div>

                    <!-- Dynamic Games -->
                    <div class="mb-4">
                        <label class="form-label">Supported Games <span class="text-danger">*</span></label>
                        <div id="gamesContainer" class="game-container"></div>
                        <button type="button" id="addGameBtn" class="btn btn-outline-light btn-sm mt-2">
                            <i class="bi bi-plus-circle"></i> Add Another Game
                        </button>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Default Key Duration (hours)</label>
                        <input type="number" name="default_duration" class="form-control" 
                               value="<?= esc($bot['default_duration']) ?>" min="1" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Code Prefix (optional)</label>
                        <input type="text" name="prefix" class="form-control" 
                               value="<?= esc($bot['prefix'] ?? '') ?>" maxlength="20">
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Welcome Message (/start)</label>
                        <textarea name="welcome_message" class="form-control" rows="4"><?= esc($bot['welcome_message'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Offline Message</label>
                        <textarea name="offline_message" class="form-control" rows="4"><?= esc($bot['offline_message'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Bot Status</label>
                        <select name="status" class="form-select">
                            <option value="active" <?= $bot['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= $bot['status'] === 'inactive' ? 'selected' : '' ?>>Inactive (Offline)</option>
                        </select>
                    </div>

                    <hr class="my-4">

                    <button type="submit" class="btn btn-outline-light w-100 py-3 fw-semibold">
                        <i class="bi bi-save me-2"></i> Save Changes
                    </button>
                </form>
            </div>
        </div>
        
        <div class="text-center mt-4">
            <a href="<?= site_url('bots') ?>" class="btn btn-outline-light">
                <i class="bi bi-arrow-left me-2"></i> Back to Bots List
            </a>
        </div>
    </div>
</div>

<script>
const allGames = <?= json_encode($game_list) ?>;
let selectedGames = <?= json_encode(array_filter(array_map('trim', explode(',', $bot['games'] ?? '')))) ?>;

function renderGameRows() {
    const container = document.getElementById('gamesContainer');
    container.innerHTML = '';

    selectedGames.forEach((val, index) => {
        const row = document.createElement('div');
        row.className = 'game-row';

        const select = document.createElement('select');
        select.className = 'form-select';
        select.name = 'games[]';
        select.required = true;

        const empty = document.createElement('option');
        empty.value = '';
        empty.textContent = '— Select Game —';
        select.appendChild(empty);

        Object.keys(allGames).forEach(key => {
            if (selectedGames.includes(key) && selectedGames.indexOf(key) !== index) return;
            const opt = document.createElement('option');
            opt.value = key;
            opt.textContent = allGames[key];
            if (key === val) opt.selected = true;
            select.appendChild(opt);
        });

        select.addEventListener('change', () => {
            selectedGames[index] = select.value;
            renderGameRows();
        });

        row.appendChild(select);

        if (selectedGames.length > 1) {
            const removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'btn btn-danger btn-sm';
            removeBtn.innerHTML = '<i class="bi bi-trash"></i>';
            removeBtn.addEventListener('click', () => {
                selectedGames.splice(index, 1);
                renderGameRows();
            });
            row.appendChild(removeBtn);
        }

        container.appendChild(row);
    });
}

document.getElementById('addGameBtn').addEventListener('click', () => {
    if (selectedGames.length >= Object.keys(allGames).length) {
        alert('Maximum number of games reached!');
        return;
    }
    selectedGames.push('');
    renderGameRows();
});

renderGameRows();
</script>

<?= $this->endSection() ?>