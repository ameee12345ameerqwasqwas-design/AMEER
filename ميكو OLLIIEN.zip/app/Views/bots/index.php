<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .status-active { background:rgba(20,82,20,0.25); color:#4ada4a; padding:5px 14px; border-radius:20px; font-size:0.82rem; border:1px solid rgba(30,122,30,0.35); }
      .status-inactive { background:rgba(139,26,26,0.25); color:#f08080; padding:5px 14px; border-radius:20px; font-size:0.82rem; border:1px solid rgba(192,57,43,0.35); }
      .game-badge { background:rgba(139,26,26,0.18); color:#e05050; padding:3px 10px; border-radius:20px; font-size:0.78rem; margin-right:4px; margin-bottom:3px; display:inline-block; border:1px solid rgba(139,26,26,0.3); }
      .dropdown-menu { background:rgba(5,14,30,0.97); border:1px solid rgba(139,26,26,0.3); border-radius:12px; backdrop-filter:blur(16px); }
      .dropdown-item { color:#c8d4ec; padding:10px 18px; }
      .dropdown-item:hover { background:rgba(139,26,26,0.2); color:#fff; }
  </style>

<div class="row justify-content-center mt-4">
    <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>

    <div class="col-lg-12">
        <div class="card shadow-sm animate-in">
            <div class="card-header text-white">
                <div class="row align-items-center">
                    <div class="col pt-1">
                        <i class="bi bi-robot me-2"></i> Telegram Bots Management
                    </div>
                    <div class="col text-end">
                        <a href="<?= site_url('bots/create') ?>" class="btn btn-success">
                            <i class="bi bi-plus-circle me-2"></i> Add New Bot
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="card-body">
                <?php if (empty($bots)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-robot display-1 text-white-50"></i>
                        <h5 class="mt-3">No bots yet</h5>
                        <p class="text-white-50">Create your first Telegram bot to get started.</p>
                        <a href="<?= site_url('bots/create') ?>" class="btn btn-success">Create First Bot</a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Bot Name</th>
                                    <th>Games</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th width="280">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($bots as $bot): ?>
                                <tr>
                                    <td><?= $bot['id'] ?></td>
                                    <td><strong>@<?= esc($bot['name']) ?></strong></td>
                                    <td>
                                        <?php 
                                        $gamesList = array_filter(array_map('trim', explode(',', $bot['games'] ?? '')));
                                        if (empty($gamesList)): 
                                        ?>
                                            <span class="text-white-50">— No games —</span>
                                        <?php else: 
                                            foreach ($gamesList as $game):
                                                if (!empty($game) && isset($game_list[$game])):
                                        ?>
                                                    <span class="game-badge"><?= esc($game_list[$game]) ?></span>
                                        <?php 
                                                endif;
                                            endforeach; 
                                        endif;
                                        ?>
                                    </td>
                                    <td>
                                        <span class="badge <?= $bot['status'] === 'active' ? 'status-active' : 'status-inactive' ?>">
                                            <?= $bot['status'] === 'active' ? 'Active' : 'Offline' ?>
                                        </span>
                                    </td>
                                    <td><small class="text-white-50"><?= $bot['created_at'] ?></small></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?= site_url('bots/edit/' . $bot['id']) ?>" class="btn btn-outline-info btn-action">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            <a href="<?= site_url('bots/toggle/' . $bot['id']) ?>" class="btn btn-<?= $bot['status'] === 'active' ? 'warning' : 'success' ?> btn-action">
                                                <i class="bi bi-<?= $bot['status'] === 'active' ? 'pause' : 'play' ?>"></i>
                                            </a>
                                            <a href="<?= site_url('bots/reset/' . $bot['id']) ?>" class="btn btn-outline-primary btn-action" onclick="return confirm('Reset webhook?')">
                                                <i class="bi bi-arrow-repeat"></i>
                                            </a>
                                            <a href="<?= site_url('bots/delete/' . $bot['id']) ?>" class="btn btn-danger btn-action" onclick="return confirm('Delete permanently?')">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>