<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .btn-gradient { background:linear-gradient(135deg,#8b1a1a,#c0392b) !important; border:none !important; color:#fff !important; font-weight:600; border-radius:9px; transition:all 0.25s; }
      .btn-gradient:hover { background:linear-gradient(135deg,#c0392b,#e74c3c) !important; transform:translateY(-2px); }
  </style>

<div class="row justify-content-center pt-4">
    <div class="col-lg-9">
        <?= $this->include('Layout/msgStatus') ?>
    </div>

    <div class="col-lg-9 mb-5 animate-in" style="animation-delay: 0.1s">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <i class="bi bi-person-badge me-2"></i> Account Info &middot; <?= esc(getName($target)) ?>
                    </div>
                    <div>
                        <a class="btn btn-back" href="<?= site_url('admin/manage-users') ?>">
                            <i class="bi bi-arrow-left me-2"></i> Back
                        </a>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <?= form_open() ?>
                <input type="hidden" name="user_id" value="<?= esc($target->id_users) ?>">

                <div class="row">
                    <div class="col-md-6 mb-4">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" name="username" id="username" class="form-control" 
                               placeholder="Enter username" 
                               value="<?= esc($username_value) ?>">
                        <?php if (!empty($errors['username'])) : ?>
                            <small class="text-danger"><?= esc($errors['username']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="fullname" class="form-label">Fullname</label>
                        <input type="text" name="fullname" id="fullname" class="form-control" 
                               placeholder="Enter full name" 
                               value="<?= esc($fullname_value) ?>">
                        <?php if (!empty($errors['fullname'])) : ?>
                            <small class="text-danger"><?= esc($errors['fullname']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="level" class="form-label">Roles</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'level', 'id' => 'level'], $sel_level, esc($level_value)) ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="status" class="form-label">Status</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'status', 'id' => 'status'], $sel_status, esc($status_value)) ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="saldo" class="form-label">Saldo</label>
                        <input type="number" name="saldo" id="saldo" class="form-control" 
                               placeholder="Enter saldo amount" 
                               value="<?= esc($saldo_value) ?>">
                        <?php if (!empty($errors['saldo'])) : ?>
                            <small class="text-danger"><?= esc($errors['saldo']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="uplink" class="form-label">Uplink</label>
                        <input type="text" name="uplink" id="uplink" class="form-control" 
                               placeholder="Enter uplink" 
                               value="<?= esc($uplink_value) ?>">
                        <?php if (!empty($errors['uplink'])) : ?>
                            <small class="text-danger"><?= esc($errors['uplink']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="expiration" class="form-label">Expiration Date</label>
                        <input type="text" name="expiration" id="expiration" class="form-control" 
                               placeholder="YYYY-MM-DD HH:MM:SS" 
                               value="<?= esc($expiration_value) ?>">
                        <?php if (!empty($errors['expiration'])) : ?>
                            <small class="text-danger"><?= esc($errors['expiration']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="col-12 mt-4">
                        <button type="submit" class="btn-gradient">
                            <i class="bi bi-save me-2"></i> Update Account Information
                        </button>
                    </div>
                </div>

                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const animatedElements = document.querySelectorAll('.animate-in');
        animatedElements.forEach(element => {
            element.style.animationPlayState = 'running';
        });
    });
</script>
<?= $this->endSection() ?>