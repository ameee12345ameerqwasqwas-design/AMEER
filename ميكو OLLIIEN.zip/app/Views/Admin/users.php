<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .users-container { padding:15px; }
      .alert-info-custom { background:rgba(5,12,28,0.8); border:1px solid rgba(139,26,26,0.3); color:#c8d4ec; border-radius:10px; padding:14px 18px; margin-bottom:22px; border-left:4px solid #8b1a1a; }
      .status-active { background:rgba(20,82,20,0.25); color:#4ada4a; padding:4px 12px; border-radius:20px; font-size:0.8rem; }
      .status-inactive { background:rgba(139,26,26,0.25); color:#f08080; padding:4px 12px; border-radius:20px; font-size:0.8rem; }
  </style>

<div class="users-container">
    <div class="row justify-content-center mt-3">
        <div class="col-12 animate-in" style="animation-delay: 0.1s">
            <div class="alert-info-custom" role="alert">
                <strong>INFO :</strong> Search specify user by their (username, fullname, saldo or uplink).
            </div>

            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-people-fill me-3"></i>
                        <h2 class="mb-0">𝐌𝐚𝐧𝐚𝐠𝐞 𝐔𝐬𝐞𝐫𝐬</h2>
                    </div>
                </div>

                <div class="card-body">
                    <?php if ($user_list) : ?>
                        <div class="table-responsive">
                            <table id="usersTable" class="table table-bordered table-hover text-center" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Fullname</th>
                                        <th>Level</th>
                                        <th>Saldo</th>
                                        <th>Status</th>
                                        <th>Uplink</th>
                                        <th>Expiration</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($user_list as $u) : ?>
                                        <tr>
                                            <td><?= esc($u->id_users) ?></td>
                                            <td><?= esc($u->username) ?></td>
                                            <td><?= esc($u->fullname) ?></td>
                                            <td>
                                                <span class="badge <?= esc($u->level_badge) ?>"><?= esc($u->level_text) ?></span>
                                            </td>
                                            <td>
                                                <?= $u->saldo_display ?>
                                            </td>
                                            <td>
                                                <span class="badge <?= esc($u->status_badge) ?>"><?= esc($u->status_text) ?></span>
                                            </td>
                                            <td><?= esc($u->uplink) ?></td>
                                            <td><?= esc($u->expiration_date) ?></td>
                                            <td>
                                                <a href="user/<?php echo $u->id_users ?>" class="btn btn-edit btn-sm">
                                                    <i class="bi bi-pencil-square"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else : ?>
                        <div class="text-center py-5">
                            <p class="text-muted">No users found.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>

<script>
    $(document).ready(function() {
        $('#usersTable').DataTable({
            "order": [[0, "desc"]],
            "pageLength": 25,
            "language": {
                "search": "Search users:",
                "lengthMenu": "Show _MENU_ users"
            },
            responsive: true
        });

        const animatedElements = document.querySelectorAll('.animate-in');
        animatedElements.forEach(element => {
            element.style.animationPlayState = 'running';
        });
    });
</script>
<?= $this->endSection() ?>