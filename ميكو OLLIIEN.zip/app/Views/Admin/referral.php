<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .referral-container { padding:15px; }
      .input-group-text { background:rgba(5,12,28,0.85); border:1px solid rgba(139,26,26,0.3); color:#c8d4ec; border-radius:9px 0 0 9px; }
      .btn-create { background:linear-gradient(135deg,#8b1a1a,#c0392b) !important; border:none !important; color:#fff !important; font-weight:700; border-radius:9px; padding:13px; transition:all 0.25s; width:100%; font-size:1rem; }
      .btn-create:hover { background:linear-gradient(135deg,#c0392b,#e74c3c) !important; transform:translateY(-2px); box-shadow:0 6px 20px rgba(192,57,43,0.4) !important; }
  </style>

<div class="referral-container">
    <div class="row justify-content-center mt-3">
        <div class="col-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-4 col-md-6 col-12 animate-in" style="animation-delay: 0.1s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-ticket-perforated me-2"></i> Generate <?= $title ?>
                </div>
                <div class="card-body">
                    <?= form_open() ?>

                    <div class="form-group mb-3">
                        <label for="set_saldo" class="form-label">You can set with multiple saldo</label>
                        <div class="input-group mt-2">
                            <span class="input-group-text"><i class="bi bi-currency-dollar"></i></span>
                            <input type="number" class="form-control" name="set_saldo" id="set_saldo" minlength="1" maxlength="11" value="5">
                        </div>
                        <?php if (!empty($errors['set_saldo'])) : ?>
                            <small class="text-danger"><?= esc($errors['set_saldo']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="form-group mb-3">
                        <label for="accExpire" class="form-label">Account Expiration</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'accExpire', 'id' => 'accExpire'], $accExpire, esc($accExpire_value)) ?>
                        <?php if (!empty($errors['accExpire'])) : ?>
                            <small class="text-danger"><?= esc($errors['accExpire']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="form-group mb-3">
                        <label for="accLevel" class="form-label">Account Level</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'accLevel', 'id' => 'accLevel'], $accLevel, esc($accLevel_value)) ?>
                        <?php if (!empty($errors['accLevel'])) : ?>
                            <small class="text-danger"><?= esc($errors['accLevel']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn-create">
                            <i class="bi bi-plus-circle me-2"></i> Create Code
                        </button>
                    </div>

                    <?= form_close() ?>
                </div>
            </div>
        </div>

        <div class="col-lg-8 col-md-6 col-12 animate-in" style="animation-delay: 0.2s">
            <?php if ($code) : ?>
                <div class="card">
                    <div class="card-header">
                        <i class="bi bi-clock-history me-2"></i> History Generate - Total <?= $total_code ?>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover text-center" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Referral</th>
                                        <th>Hashed</th>
                                        <th>Saldo</th>
                                        <th>Level</th>
                                        <th>Expiration</th>
                                        <th>Used by</th>
                                        <th>Create by</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($code as $c) : ?>
                                        <tr>
                                            <td><?= esc($c->id_reff) ?></td>
                                            <td><span class="badge bg-primary"><?= esc($c->Referral) ?></span></td>
                                            <td><span class="text-warning"><?= esc(substr($c->code, 1, 15)) ?></span></td>
                                            <td><span class="text-success">$<?= esc($c->set_saldo) ?></span></td>
                                            <td><?= esc($c->level) ?></td>
                                            <td><?= esc($c->acc_expiration) ?></td>
                                            <td><?= esc($c->used_by) ?: '<span class="text-muted">Not used</span>' ?></td>
                                            <td><?= esc($c->created_by) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const animatedElements = document.querySelectorAll('.animate-in');
        animatedElements.forEach(element => {
            element.style.animationPlayState = 'running';
        });
    });
</script>
<?= $this->endSection() ?>