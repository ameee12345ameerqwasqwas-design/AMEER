<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .section-card { background:rgba(5,12,28,0.6); border-radius:12px; padding:18px; margin-bottom:22px; border:1px solid rgba(139,26,26,0.18); }
      .preview-img { border:2px solid #8b1a1a; border-radius:10px; box-shadow:0 0 14px rgba(139,26,26,0.4); }
  </style>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <?= $this->include('Layout/msgStatus') ?>

            <div class="glass-card p-4">
                <h3 class="text-white mb-4 text-center">
                    <i class="bi bi-gear-fill me-2"></i> Panel Settings
                </h3>

                <!-- ==================== Panel Name Section ==================== -->
                <div class="section-card">
                    <h5 class="text-white mb-3"><i class="bi bi-pencil-square me-2"></i> Panel Name</h5>
                    <?= form_open('panelsettings', ['method' => 'post']) ?>
                        <div class="mb-3">
                            <input type="hidden" name="action" value="update_name">
                            <input type="text" name="base_name" class="form-control" 
                                   value="<?= esc($base_name ?? '') ?>" placeholder="Panel Name" required>
                        </div>
                        <button type="submit" class="btn btn-apply w-100">
                            <i class="bi bi-save me-2"></i> Apply Name Change
                        </button>
                    <?= form_close() ?>
                </div>

                <!-- ==================== Telegram Section ==================== -->
                <div class="section-card">
                    <h5 class="text-white mb-3"><i class="bi bi-telegram me-2"></i> Telegram Link</h5>
                    <?= form_open('panelsettings', ['method' => 'post']) ?>
                        <div class="mb-3">
                            <input type="hidden" name="action" value="update_telegram">
                            <input type="text" name="telegram_link" class="form-control" 
                                   value="<?= esc($telegram_link ?? '') ?>" 
                                   placeholder="@username or https://t.me/x3_2r" required>
                        </div>
                        <button type="submit" class="btn btn-apply w-100">
                            <i class="bi bi-save me-2"></i> Apply Telegram Change
                        </button>
                    <?= form_close() ?>
                </div>

                <!-- ==================== Favicon Section ==================== -->
                <div class="section-card">
                    <h5 class="text-white mb-3"><i class="bi bi-image me-2"></i> Logo</h5>
                    <?= form_open_multipart('panelsettings', ['method' => 'post']) ?>
                        <input type="hidden" name="action" value="update_favicon">
                        
                        <div class="d-flex align-items-center gap-4 mb-3">
                            <img src="<?= $favicon_url ?? base_url('assets/favicon.ico') ?>?v=<?= time() ?>" 
                                 alt="Current Favicon" class="preview-img" width="80" height="80">
                            
                            <div class="flex-grow-1">
                                <input type="file" name="favicon" accept=".ico" class="form-control">
                                <small class="text-white-50 mt-2 d-block">Only .ico files allowed (64x64 recommended)</small>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-apply w-100">
                            <i class="bi bi-upload me-2"></i> Upload & Apply Favicon
                        </button>
                    <?= form_close() ?>
                </div>

            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>