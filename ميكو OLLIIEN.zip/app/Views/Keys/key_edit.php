<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .maxDev { background:rgba(139,26,26,0.2) !important; border:1px solid rgba(139,26,26,0.4); color:#e0c8c8; padding:5px 12px !important; border-radius:20px !important; font-weight:500; font-size:0.88rem; }
      .btn-outline-info { color:#80d0f0 !important; border-color:rgba(80,160,200,0.4) !important; background:rgba(5,12,28,0.5) !important; }
      .btn-outline-info:hover { background:rgba(80,160,200,0.15) !important; color:#fff !important; }
  </style>

<div class="row pb-5 justify-content-center">
    <div class="col-lg-8">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    <div class="col-lg-8 mb-3 animate-in">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col pt-1">
                        <i class="bi bi-key-fill me-2"></i> Key Information
                    </div>
                    <div class="col">
                        <div class="text-end">
                            <a class="btn btn-sm btn-outline-light" href="<?= site_url('keys/generate') ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Generate Key"><i class="bi bi-plus-circle"></i></a>
                            <a class="btn btn-sm btn-outline-light" href="<?= site_url('keys') ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="View All Keys"><i class="bi bi-list"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= form_open('keys/edit') ?>

                <div class="row">
                    <input type="hidden" name="id_keys" value="<?= esc($key->id_keys) ?>">
                    
                    <?php if (($user->level == 1) || ($user->level == 2)) : ?>
                        <div class="col-lg-6 mb-3">
                            <label for="game" class="form-label"><i class="bi bi-controller"></i> Games</label>
                            <input type="text" name="game" id="game" class="form-control" placeholder="RandomKey" value="<?= esc($game_value) ?>">
                            <?php if (!empty($errors['game'])) : ?>
                                <small class="text-danger"><?= esc($errors['game']) ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="user_key" class="form-label"><i class="bi bi-key-fill"></i> User Key</label>
                            <input type="text" name="user_key" id="user_key" class="form-control" placeholder="RandomKey" value="<?= esc($user_key_value) ?>">
                            <?php if (!empty($errors['user_key'])) : ?>
                                <small class="text-danger"><?= esc($errors['user_key']) ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="duration" class="form-label"><i class="bi bi-clock"></i> Duration <small class="text-muted">(in hours)</small></label>
                            <input type="number" name="duration" id="duration" class="form-control" placeholder="3" value="<?= esc($duration_value) ?>">
                            <?php if (!empty($errors['duration'])) : ?>
                                <small class="text-danger"><?= esc($errors['duration']) ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label for="max_devices" class="form-label"><i class="bi bi-phone-vibrate-fill"></i> Max Devices</label>
                            <input type="number" name="max_devices" id="max_devices" class="form-control" placeholder="3" value="<?= esc($max_devices_value) ?>">
                            <?php if (!empty($errors['max_devices'])) : ?>
                                <small class="text-danger"><?= esc($errors['max_devices']) ?></small>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="col-md-6 mb-3" id="col-status">
                        <label for="status" class="form-label"><i class="bi bi-shield-check"></i> Status</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'status', 'id' => 'status'], $sel_status, esc($status_value)) ?>
                        <?php if (!empty($errors['status'])) : ?>
                            <small class="text-danger"><?= esc($errors['status']) ?></small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label for="registrator" class="form-label"><i class="bi bi-person-fill"></i> Registrator</label>
                        <input type="text" name="registrator" id="registrator" class="form-control" placeholder="nata" value="<?= esc($registrator_value) ?>">
                        <?php if (!empty($errors['registrator'])) : ?>
                            <small class="text-danger"><?= esc($errors['registrator']) ?></small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-md-12 mb-3">
                        <label for="expired_date" class="form-label"><i class="bi bi-calendar-x-fill"></i> Expired <?= $expired_badge ?></label>
                        <input type="text" name="expired_date" id="expired_date" class="form-control" placeholder="<?= $time::now() ?>" value="<?= esc($expired_date_value) ?>">
                        <?php if (!empty($errors['expired_date'])) : ?>
                            <small class="text-danger"><?= esc($errors['expired_date']) ?></small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-lg-12 mb-4">
                        <label for="devices" class="form-label"><i class="bi bi-list-ul"></i> Devices <span class="maxDev"><?= esc($key_info->total) ?>/<?= esc($key->max_devices) ?></span> <small class="text-muted">(Separately with enter)</small></label>
                        <textarea class="form-control" name="devices" id="devices" rows="<?= esc(($key_info->total > $key->max_devices) ? 3 : $key_info->total) ?>"><?= esc($devices_value) ?></textarea>
                        <?php if (!empty($errors['devices'])) : ?>
                            <small class="text-danger"><?= esc($errors['devices']) ?></small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-lg-6">
                        <button class="btn btn-outline-info btnUpdate w-100" disabled>
                            <i class="bi bi-save me-2"></i> Update User Key
                        </button>
                    </div>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        var level = "<?= $user->level ?>";
        if (level != 1) $("#registrator, #expired_date, #devices").attr('disabled', true);
        
        $("input, select, textarea").change(function() {
            $(".btnUpdate").attr('disabled', false);
        });
        
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (el) {
            return new bootstrap.Tooltip(el);
        });
        
        document.querySelectorAll('.animate-in').forEach(el => {
            el.style.animationPlayState = 'running';
        });
    });
    
    var total = "<?= esc($key_info->total) ?>";
    $("#max_devices").change(function() {
        $(".maxDev").html(total + '/' + $(this).val());
        $("#devices").attr('rows', Math.max($(this).val(), 3));
    });
</script>
<?= $this->endSection() ?>