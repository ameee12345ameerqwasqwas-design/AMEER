<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .key-display { background:rgba(5,12,28,0.8); padding:14px 18px; border-radius:10px; margin:18px 0; display:flex; justify-content:space-between; align-items:center; border:1px solid rgba(139,26,26,0.3); font-family:monospace; }
      .key-display strong { color:#e05050; word-break:break-all; }
      .copy-btn { cursor:pointer; transition:all 0.2s; font-size:1.2rem; color:rgba(255,255,255,0.5); padding:4px; border-radius:6px; }
      .copy-btn:hover { color:#c0392b; background:rgba(139,26,26,0.15); }
      .alert-success { background:rgba(20,82,20,0.15) !important; border:1px solid rgba(30,122,30,0.4) !important; color:#6dda6d !important; border-radius:10px; padding:18px; }
      .duration-slider-container { margin:18px 0; padding:16px; background:rgba(5,12,28,0.7); border-radius:10px; border:1px solid rgba(139,26,26,0.2); }
      .slider-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; }
      .slider-header h6 { color:#c8d4ec; margin:0; font-weight:600; }
      .duration-display { background:rgba(139,26,26,0.2); color:#fff; padding:5px 12px; border-radius:8px; font-weight:600; font-size:14px; min-width:110px; text-align:center; border:1px solid rgba(139,26,26,0.35); }
      .form-check-input { background:rgba(5,12,28,0.8) !important; border-color:rgba(139,26,26,0.5) !important; }
      .form-check-input:checked { background:#8b1a1a !important; border-color:#b02020 !important; }
      .form-check-label { color:#c8d4ec; font-weight:500; font-size:14px; }
      .key-sensi { filter:blur(5px); transition:filter 0.3s; font-family:monospace; background:rgba(139,26,26,0.1); padding:2px 8px; border-radius:5px; color:#fff; }
      .key-sensi:hover { filter:blur(0); }
  </style>

<div class="row justify-content-center mt-4">
    <div class="col-lg-6">
        <?= $this->include('Layout/msgStatus') ?>
        
        <?php if (session()->getFlashdata('user_key')) : ?>
            <div class="card mb-4 animate-in" style="animation-delay: 0.1s">
                <div class="card-header">
                    <i class="bi bi-check-circle-fill me-2"></i> License Generated Successfully
                </div>
                <div class="card-body">
                    <div class="alert alert-success" role="alert">
                        <div class="mb-3">
                            <strong><i class="bi bi-controller me-2"></i>Game:</strong> 
                            <?= session()->getFlashdata('game') ?> / <?= session()->getFlashdata('duration') ?> Hours
                        </div>
                        <div class="mb-3">
                            <strong><i class="bi bi-key me-2"></i>License:</strong> 
                            <span class="key-sensi"><?= session()->getFlashdata('user_key') ?></span>
                        </div>
                        <div class="mb-3">
                            <strong><i class="bi bi-phone-vibrate-fill me-2"></i>Available for:</strong> 
                            <?= session()->getFlashdata('max_devices') ?> Devices
                        </div>
                        <small class="text-white-80">
                            <i class="bi bi-info-circle me-1"></i>
                            Duration will start when license is activated.
                        </small>
                    </div>
                    
                    <div class="key-display">
                        <strong><?= session()->getFlashdata('user_key') ?></strong>
                        <i class="bi bi-clipboard copy-btn" id="copybtn" onclick="copyText()" title="Copy to clipboard"></i>
                    </div>
                    
                    <textarea name="mytext" id="mytext"><?= session()->getFlashdata('user_key') ?></textarea>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="card animate-in" style="animation-delay: 0.2s">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col">
                        <i class="bi bi-key-fill me-2"></i> Create License
                    </div>
                    <div class="col text-end">
                        <a class="btn btn-sm btn-outline-dark d-inline-flex align-items-center" href="<?= site_url('keys') ?>">
                            <i class="bi bi-list-ul me-1"></i> View Keys
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <div class="row">
                    <div class="form-group col-lg-6 mb-3">
                        <label for="game" class="form-label"><i class="bi bi-controller"></i> Game</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'game', 'id' => 'game'], $game, esc($game_value)) ?>
                    </div>
                    <div class="form-group col-lg-6 mb-3">
                        <label for="max_devices" class="form-label"><i class="bi bi-phone-vibrate-fill"></i> Max Devices</label>
                        <input type="number" name="max_devices" id="max_devices" class="form-control" placeholder="Enter number of devices" value="<?= esc($max_devices_value) ?>" min="1">
                    </div>
                </div>

                <div class="toggle-switch">
                    <div class="toggle-btn active" onclick="showSlider()">Slider</div>
                    <div class="toggle-btn" onclick="showDropdown()">Dropdown</div>
                </div>

                <div id="sliderMode">
                    <div class="form-group mb-3">
                        <label class="form-label"><i class="bi bi-clock-history"></i> Duration (Slider)</label>
                        <div class="duration-slider-container">
                            <div class="slider-header">
                                <h6>Select Duration</h6>
                                <div class="duration-display" id="durationDisplay">1 Day (24 Hours)</div>
                            </div>
                            <input type="range" class="duration-slider" id="durationSlider" min="1" max="365" value="1" oninput="updateFromSlider(this.value)">
                            <div class="duration-presets">
                                <div class="duration-preset active" onclick="setPreset(1)">1 Day</div>
                                <div class="duration-preset" onclick="setPreset(7)">1 Week</div>
                                <div class="duration-preset" onclick="setPreset(30)">1 Month</div>
                                <div class="duration-preset" onclick="setPreset(90)">3 Months</div>
                                <div class="duration-preset" onclick="setPreset(180)">6 Months</div>
                                <div class="duration-preset" onclick="setPreset(365)">1 Year</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="dropdownMode" style="display: none;">
                    <div class="form-group mb-3">
                        <label for="duration" class="form-label"><i class="bi bi-calendar-week"></i> Duration (Dropdown)</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'duration', 'id' => 'duration'], $duration, esc($duration_value)) ?>
                    </div>
                </div>

                <input type="hidden" name="slider_duration" id="sliderDuration" value="24">

                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" value="" name="check" onchange="fupi(this)" id="check">
                    <label class="form-check-label d-flex align-items-center" for="check">
                        <i class="bi bi-pencil-square"></i> Custom License Key
                    </label>
                </div>

                <div class="form-group mb-3" id="custom-container" style="display: none;">
                    <label for="custom" class="form-label"><i class="bi bi-keyboard"></i> Input Your Key</label>
                    <input type="text" minlength="4" maxlength="25" name="cuslicense" class="form-control" id="custom" placeholder="Enter custom license key">
                </div>
                
                <div class="form-group mb-3" id="bulk-container">
                    <label for="hulala" class="form-label"><i class="bi bi-collection-play"></i> Bulk Keys</label>         
                    <select class="form-select" id="hulala" name="loopcount">
                        <option value="5">1 Key</option>
                        <option value="1">5 Keys</option>
                        <option value="2">10 Keys</option>
                        <option value="3">25 Keys</option>
                        <option value="4">50 Keys</option>
                        <option value="5">100 Keys</option>
                    </select>
                </div>
                
                <input type="hidden" id="textinput" name="custominput" value="auto">
                
                <div class="form-group mb-4">
                    <label for="estimation" class="form-label"><i class="bi bi-currency-dollar"></i> Estimated Cost</label>
                    <input type="text" id="estimation" class="form-control" placeholder="Calculating..." readonly>
                </div>
                
                <div class="form-group mt-4">
                    <button type="submit" class="btn btn-outline-dark w-100 d-flex justify-content-center align-items-center py-2">
                        <i class="bi bi-sparkle me-2"></i>
                        <span>Generate License</span>
                    </button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<script>
    function showSlider() {
        document.getElementById('sliderMode').style.display = 'block';
        document.getElementById('dropdownMode').style.display = 'none';
        document.querySelectorAll('.toggle-btn')[0].classList.add('active');
        document.querySelectorAll('.toggle-btn')[1].classList.remove('active');
    }

    function showDropdown() {
        document.getElementById('sliderMode').style.display = 'none';
        document.getElementById('dropdownMode').style.display = 'block';
        document.querySelectorAll('.toggle-btn')[0].classList.remove('active');
        document.querySelectorAll('.toggle-btn')[1].classList.add('active');
        updateSliderFromDropdown();
    }

    function updateFromSlider(days) {
        const hours = days * 24;
        document.getElementById('sliderDuration').value = hours;
        document.getElementById('durationDisplay').textContent = days + (days > 1 ? " Days" : " Day") + " (" + hours + " Hours)";
        updateDropdownFromSlider(hours);
        updateEstimation();
    }

    function updateDropdownFromSlider(hours) {
        const dropdown = document.getElementById('duration');
        let closest = dropdown.options[0];
        let minDiff = Math.abs(hours - parseInt(dropdown.options[0].value));
        for (let opt of dropdown.options) {
            let diff = Math.abs(hours - parseInt(opt.value));
            if (diff < minDiff) {
                minDiff = diff;
                closest = opt;
            }
        }
        dropdown.value = closest.value;
    }

    function updateSliderFromDropdown() {
        const hours = parseInt(document.getElementById('duration').value) || 24;
        const days = Math.round(hours / 24);
        document.getElementById('durationSlider').value = days;
        document.getElementById('sliderDuration').value = hours;
        document.getElementById('durationDisplay').textContent = days + (days > 1 ? " Days" : " Day") + " (" + hours + " Hours)";
        updateEstimation();
    }

    function setPreset(days) {
        document.getElementById('durationSlider').value = days;
        updateFromSlider(days);
        document.querySelectorAll('.duration-preset').forEach(p => p.classList.remove('active'));
        event.target.classList.add('active');
    }

    function updateEstimation() {
        const devices = parseInt(document.getElementById('max_devices').value) || 1;
        const hours = parseInt(document.getElementById('sliderDuration').value) || 24;
        const days = Math.ceil(hours / 24);
        const total = (devices * 80 * days).toFixed(2);
        document.getElementById('estimation').value = '$' + total;
    }

    function copyText() {
        const txt = document.getElementById("mytext");
        txt.select();
        document.execCommand("copy");
        const btn = document.getElementById("copybtn");
        const old = btn.className;
        btn.className = "bi bi-clipboard-check copy-btn";
        btn.style.color = "#2ecc71";
        setTimeout(() => {
            btn.className = old;
            btn.style.color = "";
        }, 2000);
    }

    function fupi(obj) {
        if ($(obj).is(":checked")) {
            document.getElementById("custom-container").style.display = "block";
            document.getElementById("bulk-container").style.display = "none";
            document.getElementById("textinput").value = "custom";
        } else {
            document.getElementById("custom-container").style.display = "none";
            document.getElementById("bulk-container").style.display = "block";
            document.getElementById("textinput").value = "auto";
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById("custom-container").style.display = "none";
        updateEstimation();
    });

    document.getElementById('duration').addEventListener('change', updateSliderFromDropdown);
    document.getElementById('max_devices').addEventListener('input', updateEstimation);
</script>

<?= $this->endSection() ?>