<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>
<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .status-active { background:rgba(20,82,20,0.25); color:#4ada4a; padding:4px 12px; border-radius:20px; font-size:0.8rem; border:1px solid rgba(30,122,30,0.4); }
      .status-inactive { background:rgba(139,26,26,0.25); color:#f08080; padding:4px 12px; border-radius:20px; font-size:0.8rem; border:1px solid rgba(192,57,43,0.4); }
      .input-group-text { background:rgba(5,12,28,0.8); border:1px solid rgba(139,26,26,0.3); color:#c8d4ec; }
  </style>
<div class="row justify-content-center">
    <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    <div class="col-lg-12">
        <div class="card shadow-sm animate-in">
            <div class="card-header text-white" style="background: linear-gradient(135deg, rgba(13, 27, 66, 0.6), rgba(10, 20, 55, 0.8));">
                <div class="row align-items-center">
                    <div class="col pt-1">
                        <i class="bi bi-list-ul me-2"></i> Keys Registered
                        <button class="btn btn-sm btn-outline-light ms-3" id="blur-out" data-bs-toggle="tooltip" data-bs-placement="top" title="Eye Protect">
                            <i class="bi bi-eye-slash"></i>
                        </button>
                    </div>
                    <div class="col text-end">
                        <div class="dropdown d-inline-block">
                            <a class="btn btn-outline-light btn-sm dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-three-dots-vertical me-2"></i> Menu
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?= site_url('keys/generate') ?>">
                                    <i class="bi bi-plus-circle-fill"></i> Generate Key
                                </a></li>
                                <li><a class="dropdown-item" href="<?= site_url('keys/deleteExp') ?>">
                                    <i class="bi bi-calendar-x-fill"></i> Delete Expired Keys
                                </a></li>
                                <li><a class="dropdown-item" href="<?= site_url('keys/deleteUnused') ?>">
                                    <i class="bi bi-trash-fill"></i> Delete Unused Keys  
                                </a></li>
                                <hr class="dropdown-divider">
                                <li><a class="dropdown-item" href="<?= site_url('keys/download_all_keys') ?>">
                                    <i class="bi bi-download"></i> Download All Keys
                                </a></li> 
                                <li><a class="dropdown-item" href="<?= site_url('keys/download_new_keys') ?>">
                                    <i class="bi bi-download"></i> Download New Keys
                                </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if ($keylist) : ?>
                    <div class="table-responsive">
                        <table id="datatable" class="table table-bordered table-hover text-center" style="width:100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Game</th>
                                    <th>User Keys</th>
                                    <th>Devices</th>
                                    <th>Duration</th>
                                    <th>Expired</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                <?php else : ?>
                    <p class="text-center">Nothing keys to show</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<?= $this->endSection() ?>
<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script>
    $(document).ready(function() {
        var table = $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            order: [[0, "desc"]],
            ajax: "<?= site_url('keys/api') ?>",
            columns: [
                { data: 'id', name: 'id_keys' },
                { data: 'game' },
                {
                    data: 'user_key',
                    render: function(data, type, row) {
                        var is_valid = (row.status == 'Active') ? "text-warning" : "text-danger";
                        return `<span class="${is_valid} keyBlur key-sensi">${row.user_key ? row.user_key : '&mdash;'}</span>`;
                    }
                },
                {
                    data: 'devices',
                    render: function(data, type, row) {
    let totalDevice = 0;
    if (Array.isArray(row.devices)) {
        totalDevice = row.devices.length;
    } else if (typeof row.devices === 'string') {
        totalDevice = row.devices.split(',').filter(d => d.trim()).length;
    } else if (typeof row.devices === 'number') {
        totalDevice = row.devices;
    }

    return `<span id="devMax-${row.user_key}">${totalDevice}/${row.max_devices}</span>`;
}
                },
                { data: 'duration' },
                {
                    data: 'expired',
                    name: 'expired_date',
                    render: function(data, type, row) {
                        return row.expired ? `<span class="badge bg-warning text-dark">${row.expired}</span>` : '(not started yet)';
                    }
                },
                {
                    data: null,
                    render: function(data, type, row) {
                        return `
                            <div class="d-grid gap-2 d-md-block text-center">
                                <button class="btn btn-outline-danger btn-sm" onclick="resetUserKey('${row.user_key}')" title="Reset key?"><i class="bi bi-arrow-repeat"></i></button>
                                <button class="btn btn-outline-warning btn-sm" onclick="resetUserKey1('${row.user_key}')" title="DELETE KEY?"><i class="bi bi-trash-fill"></i></button>
                                <a href="<?= site_url('keys/') ?>${row.id}" class="btn btn-outline-info btn-sm" title="Edit key information?"><i class="bi bi-pencil-square"></i></a>
                            </div>`;
                    }
                }
            ]
        });
        $("#blur-out").click(function() {
            $(".keyBlur").toggleClass("key-sensi");
            $(this).html($(".keyBlur").hasClass("key-sensi") ? `<i class="bi bi-eye-slash"></i>` : `<i class="bi bi-eye"></i>`);
        });

        // Tooltips
        $('[data-bs-toggle="tooltip"]').tooltip();
    });
function resetUserKey(keys) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This will reset all registered devices for this key.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Reset Devices'
    }).then((result) => {
        if (result.isConfirmed) {
            $.getJSON("<?= site_url('keys/reset') ?>", { userkey: keys, reset: 1 }, function(data) {
                if (data.reset) {
                    Swal.fire({
                        title: 'Reset Successful!',
                        text: 'All devices have been cleared for this key.',
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload(); 
                    });
                } else {
                    Swal.fire('Failed!', 'Could not reset devices. Please try again.', 'error');
                }
            }).fail(function() {
                Swal.fire('Error!', 'Cannot connect to server. Please check your connection.', 'error');
            });
        }
    });
}
function resetUserKey1(keys) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This action will permanently delete the key!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, Delete!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.getJSON("<?= site_url('keys/resetAll') ?>", { userkey: keys }, function(response) {
                if (response.success) {
                    Swal.fire({
                        title: 'Deleted!',
                        text: response.message,
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload(); 
                    });
                } else {
                    Swal.fire('Failed!', response.message, 'error');
                }
            }).fail(function() {
                Swal.fire('Error!', 'Connection failed. Please try again.', 'error');
            });
        }
    });
}
</script>
<?= $this->endSection() ?>