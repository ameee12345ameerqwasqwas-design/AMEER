<?= $this->extend('Layout/Starter') ?>
  <?= $this->section('content') ?>
  <style>
    body { background-color:#020810; font-family:'Poppins',sans-serif; }
    
    /* --- PAGE HEADER --- */
    .je-header {
      display:flex; align-items:center; justify-content:space-between;
      padding:22px 26px 16px;
      border-bottom:1px solid rgba(139,26,26,0.25);
      margin-bottom:24px;
    }
    .je-title { font-size:1.5rem; font-weight:800; color:#fff; }
    .je-title span { color:#c0392b; }
    .je-subtitle { color:#7080a0; font-size:0.82rem; margin-top:2px; }

    /* --- UPLOAD ZONE --- */
    .upload-zone {
      border:2px dashed rgba(139,26,26,0.4);
      border-radius:18px;
      padding:60px 30px;
      text-align:center;
      cursor:pointer;
      transition:all 0.3s;
      background:rgba(5,12,28,0.5);
      position:relative;
    }
    .upload-zone:hover,.upload-zone.dragging {
      border-color:#c0392b;
      background:rgba(139,26,26,0.08);
      box-shadow:0 0 30px rgba(139,26,26,0.15);
    }
    .upload-zone input { display:none; }
    .upload-icon { font-size:3.5rem; color:#8b1a1a; margin-bottom:14px; display:block; }
    .upload-text { color:#c8d4ec; font-size:1.05rem; font-weight:600; margin-bottom:6px; }
    .upload-sub { color:#6a7a9a; font-size:0.85rem; }
    .upload-btn-label {
      display:inline-block; margin-top:18px;
      padding:11px 28px; border-radius:10px;
      background:linear-gradient(135deg,#8b1a1a,#c0392b);
      color:#fff; font-weight:700; font-size:0.9rem;
      cursor:pointer; transition:all 0.25s;
      box-shadow:0 4px 16px rgba(192,57,43,0.3);
    }
    .upload-btn-label:hover { background:linear-gradient(135deg,#c0392b,#e74c3c); transform:translateY(-2px); }

    /* --- EDITOR LAYOUT --- */
    .editor-layout { display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-top:4px; }
    @media(max-width:900px){ .editor-layout { grid-template-columns:1fr; } }

    /* --- FIELDS PANEL (LEFT) --- */
    .fields-panel {
      background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97));
      border:1px solid rgba(139,26,26,0.2);
      border-left:4px solid #8b1a1a;
      border-radius:14px;
      overflow:hidden;
    }
    .panel-header {
      background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35));
      border-bottom:1px solid rgba(139,26,26,0.3);
      padding:14px 20px;
      display:flex; align-items:center; justify-content:space-between;
    }
    .panel-title { color:#fff; font-weight:700; font-size:0.95rem; display:flex; align-items:center; gap:8px; }
    .panel-badge { background:rgba(139,26,26,0.3); color:#e05050; padding:2px 10px; border-radius:12px; font-size:0.75rem; }
    .panel-body { padding:18px; max-height:70vh; overflow-y:auto; }
    .panel-body::-webkit-scrollbar { width:4px; }
    .panel-body::-webkit-scrollbar-thumb { background:#8b1a1a; border-radius:2px; }

    /* --- FIELD ITEMS --- */
    .field-group { margin-bottom:18px; position:relative; }
    .field-group.nested {
      padding:14px 16px;
      background:rgba(5,12,28,0.5);
      border:1px solid rgba(139,26,26,0.15);
      border-left:3px solid rgba(139,26,26,0.5);
      border-radius:10px;
      margin-bottom:14px;
    }
    .field-path {
      font-size:0.7rem; color:#e05050; text-transform:uppercase;
      letter-spacing:1px; margin-bottom:4px; font-weight:700;
    }
    .field-key {
      font-size:0.78rem; color:#a0b4d0;
      margin-bottom:5px; display:flex; align-items:center; gap:6px;
    }
    .type-badge {
      padding:1px 7px; border-radius:8px; font-size:0.65rem; font-weight:700;
      text-transform:uppercase; letter-spacing:0.5px;
    }
    .type-string  { background:rgba(30,100,200,0.2); color:#60aaff; border:1px solid rgba(30,100,200,0.3); }
    .type-number  { background:rgba(30,180,80,0.2);  color:#50e080; border:1px solid rgba(30,180,80,0.3); }
    .type-boolean { background:rgba(200,120,20,0.2); color:#ffb040; border:1px solid rgba(200,120,20,0.3); }
    .type-null    { background:rgba(100,100,100,0.2);color:#909090; border:1px solid rgba(100,100,100,0.3); }
    .type-array   { background:rgba(140,60,180,0.2); color:#d080ff; border:1px solid rgba(140,60,180,0.3); }
    .type-object  { background:rgba(139,26,26,0.2);  color:#e05050; border:1px solid rgba(139,26,26,0.3); }

    .je-input {
      width:100%; padding:9px 14px;
      background:rgba(5,12,28,0.8);
      border:1px solid rgba(139,26,26,0.3);
      border-radius:8px; color:#fff; font-family:'Poppins',sans-serif; font-size:0.88rem;
      transition:all 0.2s; outline:none;
    }
    .je-input:focus { border-color:#c0392b; box-shadow:0 0 0 3px rgba(192,57,43,0.18); }
    .je-textarea {
      width:100%; padding:9px 14px;
      background:rgba(5,12,28,0.8);
      border:1px solid rgba(139,26,26,0.3);
      border-radius:8px; color:#fff; font-family:monospace; font-size:0.85rem;
      min-height:70px; resize:vertical; outline:none; transition:all 0.2s;
    }
    .je-textarea:focus { border-color:#c0392b; box-shadow:0 0 0 3px rgba(192,57,43,0.18); }

    .je-toggle-wrap { display:flex; align-items:center; gap:12px; }
    .je-toggle {
      position:relative; width:48px; height:24px;
      background:rgba(139,26,26,0.3); border-radius:12px;
      cursor:pointer; transition:all 0.3s; border:1px solid rgba(139,26,26,0.4); flex-shrink:0;
    }
    .je-toggle.on { background:#8b1a1a; border-color:#c0392b; box-shadow:0 0 8px rgba(139,26,26,0.4); }
    .je-toggle::before {
      content:''; position:absolute; top:3px; left:3px;
      width:16px; height:16px; background:#fff; border-radius:50%;
      transition:all 0.3s;
    }
    .je-toggle.on::before { transform:translateX(24px); }
    .bool-label { color:#c8d4ec; font-size:0.88rem; font-weight:500; }

    .add-field-btn {
      width:100%; padding:8px; border-radius:8px;
      border:1px dashed rgba(139,26,26,0.3);
      background:transparent; color:#8b1a1a; font-size:0.82rem; cursor:pointer;
      transition:all 0.2s; display:flex; align-items:center; justify-content:center; gap:6px;
    }
    .add-field-btn:hover { background:rgba(139,26,26,0.1); border-color:#c0392b; color:#e05050; }

    .remove-field {
      position:absolute; top:0; right:0;
      width:22px; height:22px; border-radius:6px;
      background:rgba(192,57,43,0.15); border:none; color:#c0392b;
      cursor:pointer; display:flex; align-items:center; justify-content:center;
      font-size:0.75rem; transition:all 0.2s; opacity:0;
    }
    .field-group:hover .remove-field { opacity:1; }
    .remove-field:hover { background:rgba(192,57,43,0.35); }

    /* Array items */
    .array-item {
      display:flex; align-items:flex-start; gap:8px;
      margin-bottom:8px; padding:8px 10px;
      background:rgba(5,12,28,0.4);
      border:1px solid rgba(139,26,26,0.12);
      border-radius:8px;
    }
    .array-index {
      background:rgba(139,26,26,0.2); color:#e05050;
      padding:2px 8px; border-radius:6px; font-size:0.7rem;
      font-weight:700; white-space:nowrap; margin-top:10px;
    }

    /* --- PREVIEW PANEL (RIGHT) --- */
    .preview-panel {
      background:linear-gradient(145deg,rgba(5,10,24,0.96),rgba(8,14,28,0.98));
      border:1px solid rgba(139,26,26,0.2);
      border-left:4px solid rgba(139,26,26,0.5);
      border-radius:14px; overflow:hidden; position:sticky; top:20px;
    }
    .preview-content {
      padding:18px; font-family:'Courier New',monospace; font-size:0.82rem;
      color:#c8d4ec; white-space:pre; overflow:auto; max-height:70vh;
    }
    .preview-content::-webkit-scrollbar { width:4px; height:4px; }
    .preview-content::-webkit-scrollbar-thumb { background:#8b1a1a; border-radius:2px; }
    /* JSON syntax highlight */
    .jk { color:#60aaff; } /* key */
    .js { color:#a0d870; } /* string value */
    .jn { color:#ffb040; } /* number */
    .jb { color:#ff8060; } /* boolean */
    .jnull { color:#909090; }

    /* --- ACTION BUTTONS --- */
    .action-bar {
      display:flex; gap:10px; flex-wrap:wrap; align-items:center;
      padding:16px 20px;
      border-top:1px solid rgba(139,26,26,0.2);
      background:rgba(5,12,28,0.5);
    }
    .btn-save {
      background:linear-gradient(135deg,#8b1a1a,#c0392b);
      border:none; color:#fff; font-weight:700; padding:11px 28px;
      border-radius:10px; cursor:pointer; transition:all 0.25s;
      display:flex; align-items:center; gap:8px; font-size:0.9rem;
      box-shadow:0 4px 16px rgba(192,57,43,0.3);
    }
    .btn-save:hover { background:linear-gradient(135deg,#c0392b,#e74c3c); transform:translateY(-2px); box-shadow:0 6px 22px rgba(192,57,43,0.5); }
    .btn-new {
      background:rgba(5,12,28,0.8); border:1px solid rgba(139,26,26,0.4);
      color:#c8d4ec; font-weight:600; padding:11px 22px; border-radius:10px;
      cursor:pointer; transition:all 0.25s; display:flex; align-items:center; gap:8px; font-size:0.9rem;
    }
    .btn-new:hover { background:rgba(139,26,26,0.2); color:#fff; }
    .btn-copy {
      background:rgba(5,12,28,0.8); border:1px solid rgba(139,26,26,0.4);
      color:#c8d4ec; font-weight:600; padding:11px 20px; border-radius:10px;
      cursor:pointer; transition:all 0.25s; display:flex; align-items:center; gap:8px; font-size:0.9rem;
    }
    .btn-copy:hover { background:rgba(30,100,200,0.15); border-color:rgba(30,100,200,0.4); color:#60aaff; }

    .file-name-badge {
      margin-left:auto; background:rgba(139,26,26,0.15); border:1px solid rgba(139,26,26,0.3);
      color:#e05050; padding:5px 14px; border-radius:8px; font-size:0.8rem; font-weight:600;
    }
    .empty-state {
      text-align:center; padding:60px 20px;
      color:#5a6a80;
    }
    .empty-icon { font-size:3rem; margin-bottom:12px; display:block; opacity:0.5; }
    .toast-msg {
      position:fixed; bottom:30px; left:50%; transform:translateX(-50%);
      background:linear-gradient(135deg,#8b1a1a,#c0392b); color:#fff;
      padding:12px 28px; border-radius:12px; font-weight:600; z-index:9999;
      box-shadow:0 6px 24px rgba(192,57,43,0.5);
      animation:toastIn 0.3s ease-out;
      pointer-events:none;
    }
    @keyframes toastIn { from{opacity:0;transform:translateX(-50%) translateY(20px)} to{opacity:1;transform:translateX(-50%) translateY(0)} }
  </style>

  <div style="padding:20px 18px;">

    <!-- HEADER -->
    <div class="je-header">
      <div>
        <div class="je-title"><i class="bi bi-filetype-json" style="color:#c0392b"></i> محرر <span>JSON</span></div>
        <div class="je-subtitle">ارفع ملف JSON وعدّل القيم بسهولة</div>
      </div>
      <button class="btn-new" onclick="resetEditor()">
        <i class="bi bi-plus-circle"></i> ملف جديد
      </button>
    </div>

    <!-- UPLOAD ZONE (shown when no file loaded) -->
    <div id="uploadSection">
      <div class="upload-zone" id="dropZone" onclick="document.getElementById('jsonFile').click()">
        <input type="file" id="jsonFile" accept=".json,application/json">
        <span class="upload-icon"><i class="bi bi-cloud-upload"></i></span>
        <div class="upload-text">اسحب وأفلت ملف JSON هنا</div>
        <div class="upload-sub">أو اضغط لاختيار الملف</div>
        <label class="upload-btn-label" onclick="event.stopPropagation();document.getElementById('jsonFile').click()">
          <i class="bi bi-folder2-open"></i> اختر ملف JSON
        </label>
      </div>

      <!-- OR: Paste JSON directly -->
      <div style="margin-top:20px;">
        <div class="fields-panel">
          <div class="panel-header">
            <div class="panel-title"><i class="bi bi-clipboard-data"></i> أو الصق JSON مباشرة</div>
          </div>
          <div class="panel-body" style="max-height:none;">
            <textarea id="pasteArea" class="je-textarea" rows="6" placeholder='{ "key": "value", "number": 42, "active": true }'></textarea>
            <button class="btn-save" style="margin-top:12px;width:auto;" onclick="loadFromPaste()">
              <i class="bi bi-lightning-fill"></i> تحميل وتحرير
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- EDITOR (shown after file loaded) -->
    <div id="editorSection" style="display:none;">
      <div class="editor-layout">

        <!-- LEFT: Fields -->
        <div class="fields-panel">
          <div class="panel-header">
            <div class="panel-title">
              <i class="bi bi-pencil-square"></i> الحقول
              <span class="panel-badge" id="fieldCount">0 حقل</span>
            </div>
            <button class="btn-new" style="padding:6px 14px;font-size:0.8rem;" onclick="addRootField()">
              <i class="bi bi-plus"></i> إضافة
            </button>
          </div>
          <div class="panel-body" id="fieldsContainer">
            <div class="empty-state">
              <span class="empty-icon">📂</span>
              <div>لا توجد حقول</div>
            </div>
          </div>
          <div class="action-bar">
            <button class="btn-save" onclick="downloadJson()">
              <i class="bi bi-download"></i> تحميل JSON
            </button>
            <button class="btn-copy" onclick="copyJson()">
              <i class="bi bi-clipboard"></i> نسخ
            </button>
            <span class="file-name-badge" id="fileNameBadge">file.json</span>
          </div>
        </div>

        <!-- RIGHT: Preview -->
        <div class="preview-panel">
          <div class="panel-header">
            <div class="panel-title"><i class="bi bi-eye"></i> معاينة مباشرة</div>
            <div style="color:#6a7a9a;font-size:0.75rem;">يتحدث تلقائياً</div>
          </div>
          <div class="preview-content" id="jsonPreview">// سيظهر هنا معاينة JSON</div>
        </div>
      </div>
    </div>

  </div>

  <script>
  let jsonData = null;
  let fileName = 'edited.json';

  // ── File upload ──
  document.getElementById('jsonFile').addEventListener('change', function(e){
    const file = e.target.files[0];
    if(!file) return;
    fileName = file.name;
    const reader = new FileReader();
    reader.onload = ev => loadJson(ev.target.result);
    reader.readAsText(file);
  });

  // ── Drag & Drop ──
  const dz = document.getElementById('dropZone');
  ['dragenter','dragover'].forEach(e => dz.addEventListener(e, ev => { ev.preventDefault(); dz.classList.add('dragging'); }));
  ['dragleave','drop'].forEach(e => dz.addEventListener(e, ev => { ev.preventDefault(); dz.classList.remove('dragging'); }));
  dz.addEventListener('drop', ev => {
    const file = ev.dataTransfer.files[0];
    if(!file) return;
    fileName = file.name;
    const reader = new FileReader();
    reader.onload = e => loadJson(e.target.result);
    reader.readAsText(file);
  });

  function loadFromPaste(){
    const text = document.getElementById('pasteArea').value.trim();
    if(!text) return showToast('الصق JSON أولاً');
    loadJson(text);
  }

  function loadJson(text){
    try {
      jsonData = JSON.parse(text);
      document.getElementById('uploadSection').style.display = 'none';
      document.getElementById('editorSection').style.display = 'block';
      document.getElementById('fileNameBadge').textContent = fileName;
      renderFields();
      updatePreview();
      showToast('✅ تم تحميل الملف');
    } catch(e){
      showToast('⚠️ JSON غير صالح: ' + e.message);
    }
  }

  function resetEditor(){
    jsonData = null;
    fileName = 'edited.json';
    document.getElementById('uploadSection').style.display = 'block';
    document.getElementById('editorSection').style.display = 'none';
    document.getElementById('jsonFile').value = '';
    document.getElementById('pasteArea').value = '';
  }

  // ── Render fields recursively ──
  function renderFields(){
    const c = document.getElementById('fieldsContainer');
    c.innerHTML = '';
    if(!jsonData || typeof jsonData !== 'object'){
      c.innerHTML = '<div class="empty-state"><span class="empty-icon">📂</span><div>لا توجد حقول</div></div>';
      return;
    }
    renderObject(c, jsonData, '');
    updateFieldCount();
  }

  function getType(val){
    if(val === null) return 'null';
    if(Array.isArray(val)) return 'array';
    return typeof val;
  }

  function renderObject(container, obj, path){
    const keys = Object.keys(obj);
    keys.forEach(key => {
      const val = obj[key];
      const fullPath = path ? path + '.' + key : key;
      renderField(container, key, val, fullPath, obj);
    });
  }

  function renderField(container, key, val, path, parentObj){
    const type = getType(val);
    const div = document.createElement('div');
    div.className = 'field-group' + (type === 'object' || type === 'array' ? ' nested' : '');
    div.dataset.path = path;

    const removeBtn = `<button class="remove-field" onclick="removeField('${path}')" title="حذف"><i class="bi bi-x"></i></button>`;

    if(type === 'object'){
      div.innerHTML = `
        ${removeBtn}
        <div class="field-path">${path}</div>
        <div class="field-key"><i class="bi bi-braces" style="color:#c0392b"></i> ${key} <span class="type-badge type-object">object</span></div>
      `;
      const inner = document.createElement('div');
      inner.style.marginTop = '10px';
      renderObject(inner, val, path);
      div.appendChild(inner);
      const addBtn = document.createElement('button');
      addBtn.className = 'add-field-btn';
      addBtn.style.marginTop = '8px';
      addBtn.innerHTML = '<i class="bi bi-plus-circle"></i> إضافة حقل';
      addBtn.onclick = () => addField(path, val, inner);
      div.appendChild(addBtn);
    } else if(type === 'array'){
      div.innerHTML = `
        ${removeBtn}
        <div class="field-path">${path}</div>
        <div class="field-key"><i class="bi bi-list-ul" style="color:#d080ff"></i> ${key} <span class="type-badge type-array">array[${val.length}]</span></div>
      `;
      const inner = document.createElement('div');
      inner.style.marginTop = '10px';
      val.forEach((item, idx) => {
        const row = document.createElement('div');
        row.className = 'array-item';
        const idxBadge = `<span class="array-index">[${idx}]</span>`;
        const itemType = getType(item);
        if(itemType === 'object' || itemType === 'array'){
          const subDiv = document.createElement('div');
          subDiv.style.flex = '1';
          subDiv.innerHTML = idxBadge + `<span class="type-badge type-${itemType}" style="margin-left:6px;margin-top:6px;display:inline-block">${itemType}</span>`;
          const subInner = document.createElement('div');
          subInner.style.marginTop = '8px';
          renderObject(subInner, item, path + '.' + idx);
          subDiv.appendChild(subInner);
          row.appendChild(subDiv);
        } else {
          row.innerHTML = idxBadge + makeInput(item, path + '.' + idx, itemType);
        }
        inner.appendChild(row);
      });
      div.appendChild(inner);
      const addBtn = document.createElement('button');
      addBtn.className = 'add-field-btn';
      addBtn.style.marginTop = '8px';
      addBtn.innerHTML = '<i class="bi bi-plus-circle"></i> إضافة عنصر';
      addBtn.onclick = () => addArrayItem(path, val, inner, div);
      div.appendChild(addBtn);
    } else {
      const inputHtml = type === 'boolean'
        ? `<div class="je-toggle-wrap">
             <div class="je-toggle ${val ? 'on' : ''}" id="tog_${path.replace(/[.\[\]]/g,'_')}" onclick="toggleBool('${path}',this)" title="${val}"></div>
             <span class="bool-label" id="boolLabel_${path.replace(/[.\[\]]/g,'_')}">${val ? 'true' : 'false'}</span>
           </div>`
        : (type === 'null'
            ? `<div class="je-input" style="color:#909090;cursor:default;opacity:0.7">null</div>`
            : makeInput(val, path, type));
      div.innerHTML = `
        ${removeBtn}
        <div class="field-key"><i class="bi bi-tag" style="color:#60aaff"></i> ${key} <span class="type-badge type-${type}">${type}</span></div>
        ${inputHtml}
      `;
    }

    container.appendChild(div);
  }

  function makeInput(val, path, type){
    const id = 'inp_' + path.replace(/[.\[\]]/g,'_');
    const isLong = typeof val === 'string' && val.length > 60;
    if(isLong){
      return `<textarea class="je-textarea" id="${id}" oninput="setVal('${path}',this.value)">${escHtml(String(val))}</textarea>`;
    }
    return `<input class="je-input" id="${id}" type="text" value="${escHtml(String(val))}" oninput="setVal('${path}',this.value,'${type}')">`;
  }

  function escHtml(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

  // ── Set value in jsonData by dotted path ──
  function setVal(path, val, type){
    const keys = parsePath(path);
    let obj = jsonData;
    for(let i=0;i<keys.length-1;i++) obj = obj[keys[i]];
    const lastKey = keys[keys.length-1];
    if(type === 'number'){
      const n = parseFloat(val);
      obj[lastKey] = isNaN(n) ? val : n;
    } else {
      obj[lastKey] = val;
    }
    updatePreview();
  }

  function toggleBool(path, el){
    const keys = parsePath(path);
    let obj = jsonData;
    for(let i=0;i<keys.length-1;i++) obj = obj[keys[i]];
    const lastKey = keys[keys.length-1];
    const newVal = !obj[lastKey];
    obj[lastKey] = newVal;
    el.classList.toggle('on', newVal);
    const labelId = 'boolLabel_' + path.replace(/[.\[\]]/g,'_');
    const label = document.getElementById(labelId);
    if(label) label.textContent = newVal ? 'true' : 'false';
    updatePreview();
  }

  function parsePath(path){
    return path.replace(/\[(\d+)\]/g,'.$1').split('.').filter(Boolean);
  }

  function removeField(path){
    const keys = parsePath(path);
    let obj = jsonData;
    for(let i=0;i<keys.length-1;i++) obj = obj[keys[i]];
    const lastKey = keys[keys.length-1];
    if(Array.isArray(obj)) obj.splice(parseInt(lastKey),1);
    else delete obj[lastKey];
    renderFields();
    updatePreview();
  }

  function addRootField(){
    const key = prompt('اسم الحقل الجديد:');
    if(!key) return;
    jsonData[key] = '';
    renderFields();
    updatePreview();
  }

  function addField(path, obj, container){
    const key = prompt('اسم الحقل الجديد:');
    if(!key) return;
    obj[key] = '';
    renderFields();
    updatePreview();
  }

  function addArrayItem(path, arr, inner, parent){
    arr.push('');
    renderFields();
    updatePreview();
  }

  // ── Preview ──
  function updatePreview(){
    try {
      const pretty = JSON.stringify(jsonData, null, 2);
      document.getElementById('jsonPreview').innerHTML = syntaxHighlight(pretty);
    } catch(e){}
  }

  function syntaxHighlight(json){
    return json
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"(\w[^"]*)"\s*:/g,'<span class="jk">"$1"</span>:')
      .replace(/:\s*"([^"]*)"/g,': <span class="js">"$1"</span>')
      .replace(/:\s*(-?\d+\.?\d*)/g,': <span class="jn">$1</span>')
      .replace(/:\s*(true|false)/g,': <span class="jb">$1</span>')
      .replace(/:\s*(null)/g,': <span class="jnull">$1</span>');
  }

  function updateFieldCount(){
    const count = document.querySelectorAll('.field-group').length;
    document.getElementById('fieldCount').textContent = count + ' حقل';
  }

  // ── Download ──
  function downloadJson(){
    try {
      const blob = new Blob([JSON.stringify(jsonData, null, 2)], {type:'application/json'});
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = fileName;
      a.click();
      showToast('✅ تم التحميل');
    } catch(e){ showToast('خطأ في التحميل'); }
  }

  function copyJson(){
    try {
      navigator.clipboard.writeText(JSON.stringify(jsonData, null, 2));
      showToast('✅ تم النسخ');
    } catch(e){ showToast('خطأ في النسخ'); }
  }

  function showToast(msg){
    const t = document.createElement('div');
    t.className = 'toast-msg';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2800);
  }
  </script>

  
  <!-- ═══════════════════════════════════════════════
       FLOATING SIDE TAB + DRAWER
  ════════════════════════════════════════════════ -->
  <style>
  /* ── Floating Tab Button ── */
  .json-side-tab {
    position:fixed;
    left:0; top:50%;
    transform:translateY(-50%);
    z-index:2000;
    background:linear-gradient(180deg,#8b1a1a,#c0392b);
    color:#fff;
    writing-mode:vertical-rl;
    text-orientation:mixed;
    padding:18px 10px;
    border-radius:0 12px 12px 0;
    cursor:pointer;
    font-weight:700;
    font-size:0.82rem;
    letter-spacing:2px;
    box-shadow:4px 0 20px rgba(139,26,26,0.6);
    border:1px solid rgba(255,255,255,0.1);
    border-left:none;
    transition:all 0.3s;
    display:flex;
    flex-direction:column;
    align-items:center;
    gap:8px;
    user-select:none;
  }
  .json-side-tab:hover {
    background:linear-gradient(180deg,#c0392b,#e74c3c);
    padding-right:14px;
    box-shadow:6px 0 28px rgba(192,57,43,0.8);
  }
  .json-side-tab .tab-icon {
    font-size:1.2rem;
    writing-mode:horizontal-tb;
  }
  .json-side-tab .tab-badge {
    background:rgba(255,255,255,0.2);
    border-radius:10px;
    padding:2px 6px;
    font-size:0.65rem;
    writing-mode:horizontal-tb;
    letter-spacing:0;
    min-width:20px;
    text-align:center;
    font-weight:800;
  }
  .json-side-tab.has-data {
    box-shadow:4px 0 24px rgba(192,57,43,0.7), 0 0 0 2px rgba(192,57,43,0.4);
  }

  /* ── Overlay ── */
  .json-drawer-overlay {
    position:fixed; inset:0;
    background:rgba(2,8,16,0.55);
    backdrop-filter:blur(4px);
    z-index:1999;
    opacity:0; visibility:hidden;
    transition:all 0.35s;
  }
  .json-drawer-overlay.open { opacity:1; visibility:visible; }

  /* ── Drawer Panel ── */
  .json-drawer {
    position:fixed;
    left:0; top:0; bottom:0;
    width:360px; max-width:92vw;
    background:linear-gradient(180deg,rgba(5,10,24,0.99),rgba(8,14,30,1));
    border-right:1px solid rgba(139,26,26,0.4);
    box-shadow:8px 0 40px rgba(0,0,0,0.8), inset 1px 0 0 rgba(139,26,26,0.15);
    z-index:2000;
    transform:translateX(-100%);
    transition:transform 0.4s cubic-bezier(0.19,1,0.22,1);
    display:flex; flex-direction:column;
    overflow:hidden;
  }
  .json-drawer.open { transform:translateX(0); }
  .json-drawer::after {
    content:'';
    position:absolute; top:0; right:0; bottom:0; width:3px;
    background:linear-gradient(180deg,transparent,#c0392b 30%,#c0392b 70%,transparent);
    opacity:0.5;
  }

  /* Drawer Header */
  .drawer-head {
    padding:18px 18px 14px;
    border-bottom:1px solid rgba(139,26,26,0.25);
    display:flex; align-items:center; justify-content:space-between;
    background:linear-gradient(90deg,rgba(139,26,26,0.2),rgba(5,10,24,0.3));
    flex-shrink:0;
  }
  .drawer-title {
    display:flex; align-items:center; gap:10px;
    color:#fff; font-weight:800; font-size:1rem;
  }
  .drawer-title i { color:#c0392b; font-size:1.2rem; }
  .drawer-file-name {
    font-size:0.72rem; color:#e05050; background:rgba(139,26,26,0.18);
    border:1px solid rgba(139,26,26,0.35); border-radius:8px;
    padding:2px 10px; margin-top:4px; display:block;
    max-width:220px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
  }
  .drawer-close {
    width:32px; height:32px; border-radius:8px;
    background:rgba(139,26,26,0.15); border:1px solid rgba(139,26,26,0.3);
    color:#d0d0d0; cursor:pointer; transition:all 0.2s;
    display:flex; align-items:center; justify-content:center; font-size:1rem;
  }
  .drawer-close:hover { background:var(--r3,#8b1a1a); color:#fff; transform:rotate(90deg); }

  /* Quick actions bar */
  .drawer-actions {
    padding:12px 14px;
    display:flex; gap:8px;
    border-bottom:1px solid rgba(139,26,26,0.15);
    flex-shrink:0;
    flex-wrap:wrap;
  }
  .dact-btn {
    flex:1; min-width:90px;
    display:flex; align-items:center; justify-content:center; gap:6px;
    padding:9px 12px; border-radius:9px; cursor:pointer;
    font-size:0.8rem; font-weight:600; transition:all 0.2s; border:none;
    white-space:nowrap;
  }
  .dact-btn.red {
    background:linear-gradient(135deg,#8b1a1a,#c0392b);
    color:#fff;
    box-shadow:0 3px 12px rgba(192,57,43,0.3);
  }
  .dact-btn.red:hover { background:linear-gradient(135deg,#c0392b,#e74c3c); transform:translateY(-1px); }
  .dact-btn.dark {
    background:rgba(5,12,28,0.8);
    border:1px solid rgba(139,26,26,0.3);
    color:#c8d4ec;
  }
  .dact-btn.dark:hover { background:rgba(139,26,26,0.18); color:#fff; }

  /* Search box */
  .drawer-search {
    padding:10px 14px;
    border-bottom:1px solid rgba(139,26,26,0.12);
    flex-shrink:0;
  }
  .drawer-search input {
    width:100%; padding:8px 14px;
    background:rgba(5,12,28,0.8);
    border:1px solid rgba(139,26,26,0.28);
    border-radius:8px; color:#fff; font-size:0.85rem; outline:none;
    transition:all 0.2s;
  }
  .drawer-search input::placeholder { color:rgba(255,255,255,0.3); }
  .drawer-search input:focus { border-color:#c0392b; box-shadow:0 0 0 2px rgba(192,57,43,0.18); }

  /* Sections list */
  .drawer-sections {
    flex:1; overflow-y:auto; padding:10px 12px;
  }
  .drawer-sections::-webkit-scrollbar { width:4px; }
  .drawer-sections::-webkit-scrollbar-thumb { background:#8b1a1a; border-radius:2px; }

  /* Empty state */
  .drawer-empty {
    text-align:center; padding:50px 20px; color:#4a5a70;
  }
  .drawer-empty i { font-size:3rem; display:block; margin-bottom:12px; opacity:0.5; }
  .drawer-empty p { font-size:0.88rem; line-height:1.6; }

  /* Section item */
  .sec-item {
    background:rgba(8,16,34,0.7);
    border:1px solid rgba(139,26,26,0.15);
    border-left:3px solid rgba(139,26,26,0.5);
    border-radius:10px;
    margin-bottom:8px;
    overflow:hidden;
    transition:all 0.2s;
  }
  .sec-item:hover { border-left-color:#c0392b; background:rgba(12,22,44,0.8); }
  .sec-item.highlighted { border-left-color:#e74c3c; box-shadow:0 0 12px rgba(231,76,60,0.2); }

  .sec-header {
    display:flex; align-items:center;
    padding:10px 12px; cursor:pointer; gap:10px;
  }
  .sec-key-badge {
    background:rgba(139,26,26,0.25); color:#e05050;
    border:1px solid rgba(139,26,26,0.4);
    border-radius:7px; padding:3px 10px;
    font-size:0.75rem; font-weight:700; font-family:monospace;
    flex-shrink:0; max-width:130px;
    overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
  }
  .sec-type-dot {
    width:8px; height:8px; border-radius:50%; flex-shrink:0;
    box-shadow:0 0 6px currentColor;
  }
  .sec-type-dot.string  { background:#60aaff; color:#60aaff; }
  .sec-type-dot.number  { background:#50e080; color:#50e080; }
  .sec-type-dot.boolean { background:#ffb040; color:#ffb040; }
  .sec-type-dot.object  { background:#e05050; color:#e05050; }
  .sec-type-dot.array   { background:#d080ff; color:#d080ff; }
  .sec-type-dot.null    { background:#707070; color:#707070; }

  .sec-preview {
    flex:1; color:#8090a8; font-size:0.78rem; font-family:monospace;
    overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
    max-width:110px;
  }
  .sec-expand-icon {
    color:#5a6a80; font-size:0.75rem; transition:transform 0.25s; flex-shrink:0;
  }
  .sec-item.expanded .sec-expand-icon { transform:rotate(180deg); }

  .sec-body {
    display:none; padding:0 12px 10px;
  }
  .sec-item.expanded .sec-body { display:block; }

  .sec-value-box {
    background:rgba(3,8,20,0.8);
    border:1px solid rgba(139,26,26,0.15);
    border-radius:8px; padding:10px;
    font-family:monospace; font-size:0.78rem;
    color:#a0d080; word-break:break-all;
    max-height:140px; overflow-y:auto;
    margin-bottom:8px; white-space:pre-wrap;
  }
  .sec-value-box::-webkit-scrollbar { width:3px; }
  .sec-value-box::-webkit-scrollbar-thumb { background:#8b1a1a; }

  .sec-btns { display:flex; gap:6px; flex-wrap:wrap; }
  .sec-btn {
    display:flex; align-items:center; gap:5px;
    padding:6px 12px; border-radius:7px;
    font-size:0.75rem; font-weight:600; cursor:pointer;
    border:none; transition:all 0.2s; white-space:nowrap;
  }
  .sec-btn.copy { background:rgba(30,100,200,0.2); color:#60aaff; border:1px solid rgba(30,100,200,0.3); }
  .sec-btn.copy:hover { background:rgba(30,100,200,0.35); color:#fff; }
  .sec-btn.dl { background:rgba(139,26,26,0.2); color:#e05050; border:1px solid rgba(139,26,26,0.3); }
  .sec-btn.dl:hover { background:rgba(192,57,43,0.35); color:#fff; }
  .sec-btn.edit { background:rgba(50,180,50,0.15); color:#50d050; border:1px solid rgba(50,180,50,0.3); }
  .sec-btn.edit:hover { background:rgba(50,180,50,0.3); color:#fff; }

  /* Stats bar */
  .drawer-stats {
    padding:8px 14px;
    display:flex; gap:12px;
    border-top:1px solid rgba(139,26,26,0.15);
    background:rgba(5,10,22,0.5);
    flex-shrink:0;
  }
  .stat-pill {
    display:flex; align-items:center; gap:5px;
    font-size:0.72rem; color:#6a7a90;
  }
  .stat-pill strong { color:#c8d4ec; }
  </style>

  <!-- FLOATING TAB -->
  <div class="json-side-tab" id="jsonSideTab" onclick="toggleDrawer()" title="أقسام JSON">
    <span class="tab-icon"><i class="bi bi-braces-asterisk"></i></span>
    <span style="writing-mode:vertical-rl">أقسام JSON</span>
    <span class="tab-badge" id="sideTabBadge">0</span>
  </div>

  <!-- OVERLAY -->
  <div class="json-drawer-overlay" id="drawerOverlay" onclick="closeDrawer()"></div>

  <!-- DRAWER PANEL -->
  <div class="json-drawer" id="jsonDrawer">

    <!-- Head -->
    <div class="drawer-head">
      <div class="drawer-title">
        <i class="bi bi-braces-asterisk"></i>
        <div>
          <div>أقسام JSON</div>
          <span class="drawer-file-name" id="drawerFileName">لا يوجد ملف محمّل</span>
        </div>
      </div>
      <button class="drawer-close" onclick="closeDrawer()">
        <i class="bi bi-x-lg"></i>
      </button>
    </div>

    <!-- Quick actions -->
    <div class="drawer-actions" id="drawerActionsBar" style="display:none">
      <button class="dact-btn dark" onclick="drawerCopyAll()">
        <i class="bi bi-clipboard-check"></i> نسخ الكل
      </button>
      <button class="dact-btn red" onclick="drawerDownloadAll()">
        <i class="bi bi-download"></i> تنزيل JSON
      </button>
    </div>

    <!-- Search -->
    <div class="drawer-search" id="drawerSearchBar" style="display:none">
      <input type="text" id="drawerSearchInput" placeholder="ابحث عن قسم أو قيمة..." oninput="filterDrawerSections(this.value)">
    </div>

    <!-- Sections list -->
    <div class="drawer-sections" id="drawerSections">
      <div class="drawer-empty" id="drawerEmpty">
        <i class="bi bi-upload"></i>
        <p>ارفع ملف JSON أو الصق محتوى<br>ثم سيظهر هنا هيكل الأقسام</p>
      </div>
    </div>

    <!-- Stats bar -->
    <div class="drawer-stats" id="drawerStats" style="display:none">
      <div class="stat-pill"><i class="bi bi-layers"></i> أقسام: <strong id="statSections">0</strong></div>
      <div class="stat-pill"><i class="bi bi-card-list"></i> حقول: <strong id="statFields">0</strong></div>
      <div class="stat-pill"><i class="bi bi-file-earmark"></i> حجم: <strong id="statSize">0 B</strong></div>
    </div>
  </div>

  <script>
  // ── Drawer State ──
  let drawerOpen = false;

  function toggleDrawer() { drawerOpen ? closeDrawer() : openDrawer(); }

  function openDrawer() {
    drawerOpen = true;
    document.getElementById('jsonDrawer').classList.add('open');
    document.getElementById('drawerOverlay').classList.add('open');
  }

  function closeDrawer() {
    drawerOpen = false;
    document.getElementById('jsonDrawer').classList.remove('open');
    document.getElementById('drawerOverlay').classList.remove('open');
  }

  // ── Build Drawer from loaded jsonData ──
  function refreshDrawer() {
    const sections = document.getElementById('drawerSections');
    const empty    = document.getElementById('drawerEmpty');
    const actBar   = document.getElementById('drawerActionsBar');
    const search   = document.getElementById('drawerSearchBar');
    const stats    = document.getElementById('drawerStats');
    const tab      = document.getElementById('jsonSideTab');
    const badge    = document.getElementById('sideTabBadge');
    const fname    = document.getElementById('drawerFileName');

    if (!jsonData || typeof jsonData !== 'object') {
      empty.style.display = 'block';
      actBar.style.display = 'none';
      search.style.display = 'none';
      stats.style.display  = 'none';
      tab.classList.remove('has-data');
      badge.textContent = '0';
      fname.textContent = 'لا يوجد ملف محمّل';
      return;
    }

    // Show UI
    empty.style.display  = 'none';
    actBar.style.display = 'flex';
    search.style.display = 'block';
    stats.style.display  = 'flex';
    tab.classList.add('has-data');
    fname.textContent = fileName || 'untitled.json';

    const keys = Object.keys(jsonData);
    badge.textContent = keys.length;

    // Build section items
    sections.innerHTML = '';
    buildDrawerItems(sections, jsonData, '');

    // Stats
    const totalFields = countFields(jsonData);
    const jsonStr = JSON.stringify(jsonData);
    document.getElementById('statSections').textContent = keys.length;
    document.getElementById('statFields').textContent   = totalFields;
    document.getElementById('statSize').textContent     = formatSize(new Blob([jsonStr]).size);
  }

  function buildDrawerItems(container, obj, prefix) {
    Object.keys(obj).forEach(key => {
      const val      = obj[key];
      const type     = getType(val);
      const fullPath = prefix ? prefix + '.' + key : key;
      const valStr   = type === 'object' || type === 'array'
                       ? JSON.stringify(val, null, 2)
                       : String(val);
      const preview  = valStr.length > 30 ? valStr.substring(0, 30) + '…' : valStr;

      const item = document.createElement('div');
      item.className = 'sec-item';
      item.dataset.key = fullPath.toLowerCase();
      item.dataset.val = valStr.toLowerCase();

      const isComplex = type === 'object' || type === 'array';
      const childCount = isComplex
        ? (Array.isArray(val) ? val.length + ' عنصر' : Object.keys(val).length + ' حقل')
        : '';

      item.innerHTML = `
        <div class="sec-header" onclick="toggleSection(this)">
          <span class="sec-type-dot ${type}"></span>
          <span class="sec-key-badge" title="${fullPath}">${key}</span>
          <span class="sec-preview">${isComplex ? childCount : preview}</span>
          <i class="bi ${isComplex ? 'bi-chevron-down' : 'bi-dash'} sec-expand-icon"></i>
        </div>
        <div class="sec-body">
          <div class="sec-value-box">${escHtml(valStr)}</div>
          <div class="sec-btns">
            <button class="sec-btn copy" onclick="secCopy(event, ${JSON.stringify(valStr)})">
              <i class="bi bi-clipboard"></i> نسخ
            </button>
            <button class="sec-btn dl" onclick="secDownload(event, '${key}', ${JSON.stringify(valStr)})">
              <i class="bi bi-download"></i> تنزيل
            </button>
            ${isComplex ? `<button class="sec-btn edit" onclick="secScrollTo(event, '${fullPath}')"><i class="bi bi-pencil"></i> تعديل</button>` : ''}
          </div>
        </div>
      `;

      // Auto-expand simple values
      if (!isComplex) item.classList.add('expanded');

      container.appendChild(item);
    });
  }

  function toggleSection(el) {
    const item = el.closest('.sec-item');
    if (!item.classList.contains('sec-item')) return;
    item.classList.toggle('expanded');
  }

  // ── Search / Filter ──
  function filterDrawerSections(query) {
    const q = query.toLowerCase().trim();
    document.querySelectorAll('.sec-item').forEach(item => {
      if (!q) { item.style.display = ''; return; }
      const match = item.dataset.key.includes(q) || item.dataset.val.includes(q);
      item.style.display = match ? '' : 'none';
      if (match && q) item.classList.add('highlighted');
      else item.classList.remove('highlighted');
    });
  }

  // ── Section Actions ──
  function secCopy(e, val) {
    e.stopPropagation();
    navigator.clipboard.writeText(val).then(() => showToast('✅ تم نسخ القسم'));
  }

  function secDownload(e, key, val) {
    e.stopPropagation();
    let content = val;
    let ext = '.txt';
    try { JSON.parse(val); content = JSON.stringify(JSON.parse(val), null, 2); ext = '.json'; } catch(e2){}
    const blob = new Blob([content], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = key + ext;
    a.click();
    showToast('✅ تم تنزيل القسم');
  }

  function secScrollTo(e, path) {
    e.stopPropagation();
    closeDrawer();
    // Find the field in the editor and scroll to it
    setTimeout(() => {
      const el = document.querySelector('[data-path="' + path + '"]');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.style.outline = '2px solid #c0392b';
        el.style.borderRadius = '10px';
        setTimeout(() => { el.style.outline = ''; }, 2000);
      }
    }, 350);
  }

  // ── Drawer-level actions ──
  function drawerCopyAll() {
    try {
      navigator.clipboard.writeText(JSON.stringify(jsonData, null, 2));
      showToast('✅ تم نسخ JSON الكامل');
    } catch(e) { showToast('خطأ في النسخ'); }
  }

  function drawerDownloadAll() {
    const blob = new Blob([JSON.stringify(jsonData, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = fileName || 'export.json';
    a.click();
    showToast('✅ تم التنزيل');
  }

  // ── Helpers ──
  function countFields(obj, depth = 0) {
    if (depth > 4) return 1;
    if (typeof obj !== 'object' || obj === null) return 1;
    return Object.values(obj).reduce((s, v) => s + countFields(v, depth + 1), 0);
  }

  function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1024 / 1024).toFixed(2) + ' MB';
  }

  // Hook into existing loadJson to refresh drawer automatically
  const _origLoadJson = loadJson;
  // Patch updatePreview to also refresh drawer
  const _origUpdatePreview = updatePreview;
  function updatePreview() {
    _origUpdatePreview();
    refreshDrawer();
  }
  </script>
<?= $this->endSection() ?>
  