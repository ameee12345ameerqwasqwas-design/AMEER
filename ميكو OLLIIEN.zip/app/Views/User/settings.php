<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .btn-outline-primary,.btn-outline-success { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.4) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; }
      .btn-outline-primary:hover,.btn-outline-success:hover { background:rgba(139,26,26,0.22) !important; color:#fff !important; }
      .settings-container { padding:18px; }
  </style>

<div class="settings-container">
    <div class="row">
        <div class="col-lg-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
    </div>

    <div class="row g-4">
        <!-- Change Password Card -->
        <div class="col-lg-6 col-md-8 col-12 mx-auto animate-in" style="animation-delay: 0.1s">
            <div class="card mb-3">
                <div class="card-header">
                    <i class="bi bi-key me-2"></i> Change Password
                </div>
                <div class="card-body">
                    <?= form_open() ?>

                    <input type="hidden" name="password_form" value="1">
                    <div class="form-group mb-3">
                        <label for="current">Current Password</label>
                        <input type="password" name="current" id="current" class="form-control mt-2" placeholder="Enter your current password">
                        <?php if (!empty($errors['current'])) : ?>
                            <small class="text-danger"><?= esc($errors['current']) ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="form-group mb-3">
                        <label for="password">New Password</label>
                        <input type="password" name="password" id="password" class="form-control mt-2" placeholder="Enter your new password">
                        <?php if (!empty($errors['password'])) : ?>
                            <small class="text-danger"><?= esc($errors['password']) ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="form-group mb-3">
                        <label for="password2">Confirm Password</label>
                        <input type="password" name="password2" id="password2" class="form-control mt-2" placeholder="Confirm your new password">
                        <?php if (!empty($errors['password2'])) : ?>
                            <small class="text-danger"><?= esc($errors['password2']) ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="form-group my-3">
                        <button type="submit" class="btn btn-outline-primary">
                            <i class="bi bi-check-circle me-2"></i> Change Password
                        </button>
                    </div>
                    <?= form_close() ?>
                </div>
            </div>
        </div>

        <!-- Account Information Card -->
        <div class="col-lg-6 col-md-8 col-12 mx-auto animate-in" style="animation-delay: 0.2s">
            <div class="card mb-3">
                <div class="card-header">
                    <i class="bi bi-person-circle me-2"></i> Account Information
                </div>
                <div class="card-body">
                    <?= form_open() ?>

                    <input type="hidden" name="fullname_form" value="1">
                    <div class="form-group mb-3">
                        <label for="fullname">Full Name</label>
                        <input type="text" name="fullname" id="fullname" class="form-control mt-2" placeholder="Enter your full name" value="<?= esc($fullname_value) ?>">
                        <?php if (!empty($errors['fullname'])) : ?>
                            <small class="text-danger"><?= esc($errors['fullname']) ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="form-group my-3">
                        <button type="submit" class="btn btn-outline-success">
                            <i class="bi bi-save me-2"></i> Update Account
                        </button>
                    </div>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const animatedElements = document.querySelectorAll('.animate-in');
        animatedElements.forEach(element => {
            element.style.animationPlayState = 'running';
        });
    });
</script>
<?= $this->endSection() ?>