<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
      body {
          background-color:#020810;
          font-family:'Poppins',sans-serif;
      }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s;
          backdrop-filter:blur(14px);
          margin-bottom:24px;
      }
      .card:hover {
          border-left-color:#c0392b !important;
          box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.25);
          transform:translateY(-5px);
      }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important;
          font-weight:700;
          letter-spacing:0.4px;
          padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important;
          border-radius:9px;
          padding:11px 14px;
          transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important;
          border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important;
          color:#fff !important;
      }
      .form-select option { background:#0a1c38; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important;
          border-color:rgba(139,26,26,0.15) !important;
          color:#fff !important; font-weight:600;
          text-transform:uppercase; font-size:0.75rem; letter-spacing:1px;
      }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark {
          color:#c8d4ec !important;
          border:1px solid rgba(139,26,26,0.45) !important;
          background:rgba(5,12,28,0.5) !important;
          border-radius:8px; transition:all 0.2s;
      }
      .btn-outline-light:hover,.btn-outline-dark:hover {
          background:rgba(139,26,26,0.22) !important;
          border-color:#b02020 !important;
          color:#fff !important;
      }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .stat-card { text-align:center; padding:18px; }
      .stat-icon { font-size:2.2rem; margin-bottom:12px; color:#c0392b; animation:iconFloat 3s ease-in-out infinite; }
      @keyframes iconFloat { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
      .stat-value { font-size:2.2rem; font-weight:800; background:linear-gradient(45deg,#8b1a1a,#e74c3c); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
      .stat-label { font-size:0.85rem; opacity:0.7; text-transform:uppercase; letter-spacing:1px; color:#a0b0c8; }
      #exp { font-family:'Rajdhani',monospace; text-align:center; color:#fff; font-size:2.8rem; text-shadow:0 0 20px rgba(192,57,43,0.6); animation:pulse 2s infinite; }
      @keyframes pulse { 0%,100%{opacity:1;text-shadow:0 0 20px rgba(192,57,43,0.6)} 50%{opacity:0.75;text-shadow:0 0 35px rgba(192,57,43,0.9)} }
      .list-group-item { background:rgba(5,12,28,0.6) !important; border:1px solid rgba(139,26,26,0.15) !important; color:#c8d4ec !important; border-radius:8px !important; margin-bottom:4px; padding:12px 18px; transition:all 0.25s; }
      .list-group-item:hover { background:rgba(139,26,26,0.15) !important; transform:translateX(4px); }
      .badge.text-success { background:rgba(20,82,20,0.2) !important; color:#4ada4a !important; }
      .badge.text-danger  { background:rgba(139,26,26,0.2) !important; color:#f08080 !important; }
      .badge.text-primary { background:rgba(139,26,26,0.2) !important; color:#e05050 !important; }
      .badge.text-dark    { background:rgba(255,255,255,0.1) !important; color:#fff !important; }
      .badge.text-muted   { background:rgba(80,90,110,0.2) !important; color:#8090a8 !important; }
      .dashboard-container { padding:18px; }
  </style>

<div class="dashboard-container">
    <div class="row g-4">

        <!-- SYSTEM STATS -->
        <div class="col-lg-4 col-md-6 col-12 top-dashboard-card">
            <div class="cyber-card">
                <div class="cyber-header">
                    <i class="fas fa-database"></i> SYSTEM STATS
                </div>
                <div class="card-body">
                    <ul class="list-group mb-3">
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-key"></i> TOTAL KEYS
                            <span class="cyber-badge cyber-badge-danger">
                                <h5><?= esc($total_keys) ?></h5>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-rocket"></i> ACTIVATED
                            <span class="cyber-badge cyber-badge-warning">
                                <h5><?= esc($activated_keys) ?></h5>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-battery-half"></i> INACTIVE
                            <span class="cyber-badge cyber-badge-warning">
                                <h5><?= esc($inactive_keys) ?></h5>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-users"></i> USERS ONLINE
                            <span class="cyber-badge cyber-badge-success">
                                <h5><?= esc($total_users) ?></h5>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- USER PROFILE -->
        <div class="col-lg-4 col-md-6 col-12 top-dashboard-card">
            <div class="cyber-card">
                <div class="cyber-header">
                    <i class="fas fa-user-astronaut"></i> USER PROFILE
                </div>
                <div class="card-body">
                    <ul class="list-group mb-3">
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-user-shield"></i> CLEARANCE
                            <span class="cyber-badge cyber-badge-danger">
                                <?= getLevel($user->level) ?>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-coins"></i> CREDITS
                            <span class="cyber-badge cyber-badge-warning">
                                $<?= esc($user->saldo) ?>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-clock"></i> SESSION START
                            <span class="cyber-badge cyber-badge-success">
                                <?= $time::parse(session()->time_since)->humanize() ?>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-hourglass-end"></i> SESSION END
                            <span class="cyber-badge cyber-badge-info">
                                <?= $time::now()->difference($time::parse(session()->time_login))->humanize() ?>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- NETWORK TERMINAL + VISITOR LOGS -->
        <div class="col-lg-4 col-md-12 col-12 top-dashboard-card">
            <div class="d-flex flex-column gap-4">
                <div class="cyber-card">
                    <div class="cyber-header">
                        <i class="fas fa-network-wired"></i> NETWORK TERMINAL
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            <li class="cyber-list-item d-flex justify-content-between align-items-center">
                                <i class="fas fa-globe"></i> NODE ADDRESS
                                <span class="cyber-badge cyber-badge-danger">
                                    <h5 id="cyber-ip"><?= esc($user_ip) ?></h5>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="cyber-card">
                    <div class="cyber-header">
                        <i class="fas fa-chart-network"></i> VISITOR LOGS
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            <li class="cyber-list-item d-flex justify-content-between align-items-center">
                                <i class="fas fa-eye"></i> VISITORS
                                <span class="cyber-badge cyber-badge-danger">
                                    <h5 id="cyber-counter"><?= esc($visit_count) ?></h5>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-3">
        <!-- History Card -->
        <div class="col-lg-8 col-12 animate-in" style="animation-delay: 0.7s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-clock-history me-2"></i> History
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered table-hover text-center">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Info</th>
                                    <th>Code</th>
                                    <th>Duration</th>
                                    <th>Devices</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($history as $h) : ?>
                                <tr>
                                    <td><span class="align-middle badge text-dark">#3812<?= esc($h['id_history']) ?></span></td>
                                    <td><?= esc($h['game']) ?></td>
                                    <td><span class="align-middle badge text-dark"><?= esc($h['code']) ?>**</span></td>
                                    <td><span class="align-middle badge text-dark"><?= esc($h['duration_formatted']) ?></span></td>
                                    <td><span class="align-middle badge text-primary"><?= esc($h['devices']) ?> Devices</span></td>
                                    <td><i class="align-middle badge text-muted"><?= esc($h['time_human']) ?></i></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Activity Chart -->
        <div class="col-lg-4 col-12 animate-in" style="animation-delay: 0.8s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-activity me-2"></i> Activity
                </div>
                <div class="card-body">
                    <div class="chart-container" style="position: relative; height: 250px;">
                        <canvas id="activityChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

    document.addEventListener('DOMContentLoaded', function() {
        const animatedElements = document.querySelectorAll('.animate-in');
        animatedElements.forEach(element => {
            element.style.animationPlayState = 'running';
        });
        
        const activityCtx = document.getElementById('activityChart').getContext('2d');
        const activityChart = new Chart(activityCtx, {
            type: 'doughnut',
            data: {
                labels: ['Used Keys', 'Unused Keys'],
                datasets: [{
                    data: [<?= esc($activated_keys) ?>, <?= esc($inactive_keys) ?>],
                    backgroundColor: [
                        'rgba(74, 222, 128, 0.8)',
                        'rgba(248, 113, 113, 0.8)'
                    ],
                    borderColor: [
                        'rgba(74, 222, 128, 1)',
                        'rgba(248, 113, 113, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: 'white',
                            padding: 20
                        }
                    }
                },
                cutout: '70%'
            }
        });
    });
</script>

<?= $this->endSection() ?>