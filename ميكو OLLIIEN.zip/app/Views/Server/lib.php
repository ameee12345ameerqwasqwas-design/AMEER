<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .files-container { padding:15px; }
      .btn-gradient { background:linear-gradient(135deg,#8b1a1a,#c0392b) !important; border:none !important; color:#fff !important; font-weight:600; border-radius:10px; transition:all 0.25s; }
      .btn-gradient:hover { background:linear-gradient(135deg,#c0392b,#e74c3c) !important; transform:translateY(-2px); }
      .search-input,.form-control-custom { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; padding:11px 14px; }
      .search-input:focus,.form-control-custom:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; outline:none; color:#fff !important; }
      .file-item { background:rgba(5,12,28,0.6); border:1px solid rgba(139,26,26,0.15); border-radius:10px; padding:14px 18px; margin-bottom:8px; color:#c8d4ec; display:flex; align-items:center; justify-content:space-between; transition:all 0.2s; }
      .file-item:hover { background:rgba(139,26,26,0.12); border-color:rgba(139,26,26,0.3); }
  </style>

<!-- Toast Container -->
<div class="toast-container" id="toastContainer"></div>

<div class="files-container">
    <div class="row justify-content-center mt-3">
        <div class="col-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card animate-in" style="animation-delay: 0.1s">
                <div class="card-header">
                    <i class="bi bi-folder-fill me-2"></i> Online Files
                </div>
                <div class="card-body">
                    
                <!-- Upload Section -->
                <div class="upload-section mb-5">
                    <h5 class="section-title"><i class="bi bi-cloud-upload me-2"></i>Upload New File</h5>
                    <form id="uploadForm" enctype="multipart/form-data" class="row g-3 align-items-end">
                        <?= csrf_field() ?>
                        <div class="col-12 col-md-8">
                            <input type="file" name="file" required class="form-control form-control-custom" id="fileInput">
                        </div>
                        <div class="col-12 col-md-4">
                            <button type="submit" class="btn btn-gradient w-100">
                                <i class="bi bi-upload me-2"></i>Upload File
                            </button>
                        </div>
                    </form>

                    <!-- Progress Bar  -->
                    <div class="progress-custom mt-3 d-none" id="progressContainer">
                        <div class="d-flex justify-content-between mb-1">
                            <small id="progressText" class="text-light">Uploading...</small>
                            <small id="progressPercent" class="text-light">0%</small>
                        </div>
                        <div class="progress" style="height: 8px; background: rgba(255,255,255,0.1);">
                            <div id="progressBar" class="progress-bar progress-bar-striped progress-bar-animated" 
                                style="width: 0%; background: linear-gradient(90deg, #7a1515, #9b1f1f);"></div>
                        </div>
                    </div>

                    <small class="text-muted d-block mt-3">
                        <i class="bi bi-info-circle me-1"></i>Allowed extensions: rar, zip, so, lua, txt, log, json, cfg, ini, yaml, yml, sql, csv, xml, dat
                    </small>
                </div>

                    <!-- Search + Files Count -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="section-title mb-0"><i class="bi bi-files me-2"></i>Uploaded Files (<?= count($files) ?>)</h5>
                        <input type="text" id="searchFiles" class="search-input" placeholder="Search files...">
                    </div>

                    <?php if(empty($files)): ?>
    <div class="empty-state">
        <i class="bi bi-folder-x"></i>
        <h4>No files uploaded yet</h4>
        <p>Start by uploading your first file!</p>
    </div>
<?php else: ?>
    <div class="row g-4" id="filesGrid">
        <?php foreach($files as $f): ?>
        <div class="col-12 col-md-6 col-lg-4 file-item">
            <div class="file-card">
                <div class="d-flex align-items-center mb-3 justify-content-between">
                    <div class="d-flex align-items-center flex-grow-1 me-2">
                        <i class="bi <?= $f['icon_class'] ?> text-info me-3 fs-3 flex-shrink-0"></i>
                        <h6 class="file-name mb-0 text-truncate flex-grow-1" id="name-display-<?= $f['name_escaped'] ?>" title="<?= $f['name_escaped'] ?>">
                            <?= $f['name_escaped'] ?>
                        </h6>
                    </div>
                    <button class="btn btn-sm btn-outline-primary flex-shrink-0" onclick="startRename('<?= $f['name_escaped'] ?>')">
                        <i class="bi bi-pencil"></i>
                    </button>
                </div>

                <div id="rename-form-<?= $f['name_escaped'] ?>" class="d-none mt-3">
                    <form class="d-flex flex-column gap-2" onsubmit="event.preventDefault(); saveRename('<?= $f['name_escaped'] ?>');">
                        <div class="d-flex align-items-center gap-2">
                            <input type="text" class="form-control form-control-custom rename-input flex-grow-1" value="<?= esc($f['basename_no_ext']) ?>" id="rename-input-<?= $f['name_escaped'] ?>">
                            <small class="text-muted align-self-center">.<?= $f['ext'] ?></small>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-gradient btn-sm flex-grow-1">
                                <i class="bi bi-check"></i> Save
                            </button>
                            <button type="button" class="btn btn-outline-light btn-sm flex-grow-1" onclick="cancelRename('<?= $f['name_escaped'] ?>')">
                                <i class="bi bi-x"></i> Cancel
                            </button>
                        </div>
                    </form>
                </div>

                <div class="file-info">
                    <i class="bi bi-hdd me-1"></i>Size: <?= $f['size_formatted'] ?>
                </div>
                <div class="file-info mb-4">
                    <i class="bi bi-clock me-1"></i>Last Modified: <?= $f['modified'] ?>
                </div>
                <div class="d-flex flex-wrap gap-2 mt-auto">
                    <a href="<?= $f['view_url'] ?>" target="_blank" class="btn btn-outline-light btn-action flex-fill">
                        <i class="bi bi-eye me-1"></i>View
                    </a>
                    <a href="<?= $f['dl_url'] ?>" class="btn btn-outline-success btn-action flex-fill">
                        <i class="bi bi-download me-1"></i>Download
                    </a>
                    <button class="btn btn-outline-info btn-action flex-fill" onclick="copyLink('<?= $f['dl_url_escaped'] ?>')">
                        <i class="bi bi-clipboard"></i>Copy Link
                    </button>
                    <form method="post" action="<?= $f['delete_url'] ?>" class="d-inline w-100" onsubmit="return confirmDelete(event)">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-outline-danger btn-action w-100 mt-2">
                            <i class="bi bi-trash"></i>Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function showNotification(message, type = 'success') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast-alert ${type}`;
        toast.innerHTML = `
            <strong>${type === 'danger' ? 'Error!' : 'Success!'}</strong><br>
            <span>${message}</span>
        `;
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'slideInRight 0.4s ease-out reverse';
            setTimeout(() => toast.remove(), 400);
        }, 4000);
    }

    function copyLink(url) {
        navigator.clipboard.writeText(url).then(() => {
            showNotification('Link copied successfully ');
        }).catch(() => {
            showNotification('Failed to copy link ', 'danger');
        });
    }

    function confirmDelete(event) {
        if (!confirm('⚠️ Are you sure you want to delete this file?')) {
            event.preventDefault();
            return false;
        }
        showNotification('Deleting file...');
        return true;
    }

    // ====================== AJAX UPLOAD ======================
    document.getElementById('uploadForm').addEventListener('submit', function(e) {
        e.preventDefault();

        const fileInput = document.getElementById('fileInput');
        if (!fileInput.files || fileInput.files.length === 0) {
            showNotification('No file selected', 'danger');
            return;
        }

        const file = fileInput.files[0];
        const ext = file.name.split('.').pop().toLowerCase();
        
        const allowed = ['rar','zip','so','lua','txt','log','json','cfg','ini','yaml','yml','sql','csv','xml','dat'];

        if (!allowed.includes(ext)) {
            showNotification('File type not allowed! Allowed: ' + allowed.join(', '), 'danger');
            return;
        }

        if (!confirm(`Upload "${file.name}"?\nSize: ${(file.size / 1024 / 1024).toFixed(2)} MB`)) {
            return;
        }

        const formData = new FormData(this);
        
        const progressContainer = document.getElementById('progressContainer');
        const progressBar       = document.getElementById('progressBar');
        const progressText      = document.getElementById('progressText');
        const progressPercent   = document.getElementById('progressPercent');

        progressContainer.classList.remove('d-none');
        progressBar.style.width = '0%';
        progressPercent.textContent = '0%';
        progressText.textContent = 'Uploading...';

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '<?= site_url("lib/upload") ?>', true);

        xhr.upload.onprogress = function(e) {
            if (e.lengthComputable) {
                const percent = Math.round((e.loaded / e.total) * 100);
                progressBar.style.width = percent + '%';
                progressPercent.textContent = percent + '%';
                if (percent >= 100) progressText.textContent = 'Processing file...';
            }
        };

        xhr.onload = function() {
            progressContainer.classList.add('d-none');

            try {
                const res = JSON.parse(this.responseText);
                if (res.success) {
                    showNotification(res.message + ' ✅', 'success');
                    setTimeout(() => location.reload(), 1200);
                } else {
                    showNotification(res.message, 'danger');
                }
            } catch (err) {
                showNotification('Server error occurred', 'danger');
            }
        };

        xhr.onerror = function() {
            progressContainer.classList.add('d-none');
            showNotification('Upload failed. Check your connection.', 'danger');
        };

        xhr.send(formData);
    });

    function startRename(filename) {
        document.getElementById('name-display-' + filename).classList.add('d-none');
        document.getElementById('rename-form-' + filename).classList.remove('d-none');
        const input = document.getElementById('rename-input-' + filename);
        input.focus();
        input.select();
    }

    function cancelRename(filename) {
        document.getElementById('name-display-' + filename).classList.remove('d-none');
        document.getElementById('rename-form-' + filename).classList.add('d-none');
    }

    async function saveRename(originalFilename) {
        const newBase = document.getElementById('rename-input-' + originalFilename).value.trim();

        if (newBase === originalFilename.replace(/\.[^/.]+$/, "")) {
            cancelRename(originalFilename);
            return;
        }

        if (newBase === '') {
            showNotification('Filename cannot be empty', 'danger');
            return;
        }

        const formData = new FormData();
        formData.append('original_name', originalFilename);
        formData.append('new_name', newBase);
        const token = document.querySelector('input[name="<?= csrf_token() ?>"]');
        if (token) formData.append('<?= csrf_token() ?>', token.value);

        try {
            showNotification('Renaming file...');
            const res = await fetch('<?= site_url("lib/rename") ?>', {
                method: 'POST',
                body: formData
            });
            const json = await res.json();

            if (json.success) {
                showNotification(json.message + ' ✅');
                setTimeout(() => location.reload(), 1500);
            } else {
                showNotification(json.message, 'danger');
                cancelRename(originalFilename);
            }
        } catch (e) {
            showNotification('Rename failed ❌', 'danger');
            cancelRename(originalFilename);
        }
    }

    document.getElementById('searchFiles')?.addEventListener('input', function() {
        const query = this.value.toLowerCase();
        document.querySelectorAll('.file-item').forEach(item => {
            const name = item.querySelector('.file-name').textContent.toLowerCase();
            item.style.display = name.includes(query) ? '' : 'none';
        });
    });

    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.animate-in').forEach((el, i) => {
            el.style.animationDelay = `${i * 0.1}s`;
        });
    });
</script>

<?= $this->endSection() ?>