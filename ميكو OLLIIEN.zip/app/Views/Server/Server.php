<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; }
      .card {
          background:linear-gradient(145deg,rgba(10,22,45,0.93),rgba(5,12,28,0.97)) !important;
          border:1px solid rgba(139,26,26,0.2) !important;
          border-left:4px solid #8b1a1a !important;
          border-radius:14px !important;
          box-shadow:0 8px 36px rgba(0,0,0,0.65),inset 0 1px 0 rgba(255,255,255,0.03);
          transition:all 0.3s; backdrop-filter:blur(14px); margin-bottom:24px;
      }
      .card:hover { border-left-color:#c0392b !important; box-shadow:0 16px 50px rgba(0,0,0,0.75),0 0 22px rgba(139,26,26,0.22); transform:translateY(-5px); }
      .card-header {
          background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.35)) !important;
          border-bottom:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; font-weight:700; letter-spacing:0.4px; padding:16px 22px;
      }
      .card-body { padding:24px; color:#dde4f0; }
      .form-control,.form-select {
          background:rgba(5,12,28,0.85) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          color:#fff !important; border-radius:9px; padding:11px 14px; transition:all 0.25s;
      }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .form-control:focus,.form-select:focus {
          background:rgba(10,22,45,0.9) !important; border-color:#c0392b !important;
          box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important;
      }
      .form-select option { background:#07142a; color:#fff; }
      .form-label { color:#c8d4ec; font-weight:500; margin-bottom:6px; }
      textarea { background:rgba(5,12,28,0.85) !important; border:1px solid rgba(139,26,26,0.3) !important; color:#fff !important; border-radius:9px; }
      textarea:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; color:#fff !important; }
      .text-muted { color:#6a7a9a !important; }
      .table { color:#c8d4ec !important; }
      .table thead th { background:linear-gradient(90deg,rgba(139,26,26,0.28),rgba(10,22,45,0.4)) !important; border-color:rgba(139,26,26,0.15) !important; color:#fff !important; font-weight:600; text-transform:uppercase; font-size:0.75rem; letter-spacing:1px; padding:13px; }
      .table tbody tr { border-color:rgba(255,255,255,0.05) !important; }
      .table-hover tbody tr:hover { background:rgba(139,26,26,0.1) !important; }
      .table-bordered { border-color:rgba(139,26,26,0.12) !important; }
      .btn-outline-light,.btn-outline-dark { color:#c8d4ec !important; border:1px solid rgba(139,26,26,0.45) !important; background:rgba(5,12,28,0.5) !important; border-radius:8px; transition:all 0.2s; }
      .btn-outline-light:hover,.btn-outline-dark:hover { background:rgba(139,26,26,0.22) !important; border-color:#b02020 !important; color:#fff !important; }
      .badge.bg-primary { background:#8b1a1a !important; }
      .badge.bg-success { background:#145214 !important; }
      .badge.bg-warning { background:#7a5500 !important; color:#ffe08a !important; }
      .animate-in { animation:fadeUp 0.45s ease-out forwards; opacity:0; }
      @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  
      .admin-container { padding:18px; }
      .section-title { color:#e05050; text-transform:uppercase; font-size:0.75rem; letter-spacing:2px; font-weight:700; margin:18px 0 10px 4px; }
      .hacks { position:relative; display:inline-block; width:78%; height:20px; float:left; margin:4%; color:#c8d4ec; font-size:0.9rem; }
      .switch { position:relative; display:inline-block; width:40px; height:20px; float:right; margin:4px; }
      .switch input { opacity:0; width:0; height:0; }
      .slider { position:absolute; cursor:pointer; inset:0; background:rgba(139,26,26,0.25); transition:.4s; border-radius:34px; border:1px solid rgba(139,26,26,0.3); }
      .slider:before { position:absolute; content:""; height:12px; width:12px; left:4px; bottom:3px; background:#fff; transition:.4s; border-radius:50%; }
      input:checked+.slider { background:#8b1a1a; box-shadow:0 0 8px rgba(139,26,26,0.5); }
      input:checked+.slider:before { transform:translateX(20px); }
  </style>

<div class="admin-container">
    <div class="row justify-content-center mt-3">
        <div class="col-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
    </div>

    <div class="row g-4 justify-content-center">
        <div class="col-lg-6 col-12">
            <?php if($user->level != 2) : ?>
            <div class="card animate-in" style="animation-delay: 0.1s">
                <div class="card-header">
                    <i class="bi bi-server me-2"></i> Server Maintenance Mode
                </div>
                <div class="card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="status_form" value="1">
                    <div class="mb-4">
                        <label class="mb-3">Current Maintenance Mode: <span class="text-info"><?= esc($onoff_data['status'] ?? 'Unknown') ?></span></label>
                        <label class="hacks">
                            Maintenance Mode
                            <div class="switch">
                                <input type="checkbox" name="radios" value="on" <?= ($onoff_data['status'] ?? '') == "on" ? 'checked' : '' ?>>
                                <span class="slider round"></span>
                            </div>
                        </label>
                    </div>
                    <div class="mb-4">
                        <label class="mb-3">Offline Message: <span class="text-info"><?= esc($onoff_data['myinput'] ?? 'No message') ?></span></label>
                        <textarea class="form-control" name="myInput" rows="3" placeholder="Server is under maintenance..."><?= esc($myInput_value) ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="bi bi-save me-2"></i> Update
                    </button>
                    <?= form_close() ?>
                </div>
            </div>

            <div class="card animate-in" style="animation-delay: 0.2s">
                <div class="card-header">
                    <i class="bi bi-pencil-square me-2"></i> Change Mod Name
                </div>
                <div class="card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="modname_form" value="1">
                    <div class="mb-4">
                        <label class="mb-3">Current Mod Name: <span class="text-info"><?= esc($modname_data['modname'] ?? 'Unknown') ?></span></label>
                        <input type="text" name="modname" class="form-control" placeholder="Enter new mod name" value="<?= esc($modname_value) ?>" required>
                    </div>
                    <button type="submit" class="btn btn-outline-warning">
                        <i class="bi bi-save me-2"></i> Update Name
                    </button>
                    <?= form_close() ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="col-lg-6 col-12">
            <div class="card animate-in" style="animation-delay: 0.3s">
                <div class="card-header">
                    <i class="bi bi-toggles me-2"></i> Mod Features
                </div>
                <div class="card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="feature_form" value="1">
                    <div class="mb-4">
                        <label class="mb-3">Current Status:</label>
                        <div class="text-info small mb-4">
                            ESP: <?= esc($feature_data['ESP'] ?? 'off') ?> | 
                            Items: <?= esc($feature_data['Item'] ?? 'off') ?> | 
                            AIM: <?= esc($feature_data['AIM'] ?? 'off') ?> | 
                            SilentAim: <?= esc($feature_data['SilentAim'] ?? 'off') ?> | 
                            BulletTrack: <?= esc($feature_data['BulletTrack'] ?? 'off') ?> | 
                            Memory: <?= esc($feature_data['Memory'] ?? 'off') ?> | 
                            Floating Texts: <?= esc($feature_data['Floating'] ?? 'off') ?> | 
                            Setting: <?= esc($feature_data['Setting'] ?? 'off') ?>
                        </div>
                        
                        <label class="hacks">ESP <div class="switch"><input type="checkbox" name="ESP" value="on" <?= $esp_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Items <div class="switch"><input type="checkbox" name="Item" value="on" <?= $item_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Aim-Bot <div class="switch"><input type="checkbox" name="AIM" value="on" <?= $aim_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Silent Aim <div class="switch"><input type="checkbox" name="SilentAim" value="on" <?= $silentAim_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Bullet Track <div class="switch"><input type="checkbox" name="BulletTrack" value="on" <?= $bulletTrack_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Memory <div class="switch"><input type="checkbox" name="Memory" value="on" <?= $memory_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Floating Texts <div class="switch"><input type="checkbox" name="Floating" value="on" <?= $floating_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Settings <div class="switch"><input type="checkbox" name="Setting" value="on" <?= $setting_checked ?>><span class="slider round"></span></div></label>
                    </div>
                    <button type="submit" class="btn btn-outline-danger">
                        <i class="bi bi-save me-2"></i> Update Features
                    </button>
                    <?= form_close() ?>
                </div>
            </div>

            <div class="card animate-in" style="animation-delay: 0.4s">
                <div class="card-header">
                    <i class="bi bi-chat-text me-2"></i> Change Floating Text
                </div>
                <div class="card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="_ftext" value="1">
                    <div class="mb-4">
                        <label class="mb-3">Current Mod Status: <span class="text-info"><?= esc($ftext_data['_status'] ?? 'Unknown') ?></span></label>
                        <label class="hacks">
                            Safe Mode
                            <div class="switch">
                                <input type="checkbox" name="_ftextr" value="Safe" <?= $safe_checked ?>>
                                <span class="slider round"></span>
                            </div>
                        </label>
                    </div>
                    <div class="mb-4">
                        <label class="mb-3">Current Floating Text: <span class="text-info"><?= esc($ftext_data['_ftext'] ?? 'No text') ?></span></label>
                        <input type="text" name="_ftext" class="form-control" placeholder="Give feedback else key removed!" value="<?= esc($_ftext_value) ?>" required>
                    </div>
                    <button type="submit" class="btn btn-outline-success">
                        <i class="bi bi-save me-2"></i> Update Text
                    </button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.animate-in').forEach((el, index) => {
            el.style.animationDelay = `${index * 0.1}s`;
            el.style.animationPlayState = 'running';
        });
    });
</script>

<?= $this->endSection() ?>