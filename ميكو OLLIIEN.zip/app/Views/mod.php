<!DOCTYPE html>
    <html dir="rtl" lang="ar">

        <head>
            <meta charset="UTF-8">
            <meta content="width=device-width,initial-scale=1" name="viewport">
            <title>سيرفر  كوكلي</title>
            <link href="favicon.ico" rel="icon" type="image/x-icon">
            <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
            <style>
      *{margin:0;padding:0;box-sizing:border-box}
      body{font-family:'Poppins',sans-serif;background-color:#020810;color:#fff;min-height:100vh;overflow-x:hidden;position:relative}
      body::before{content:'';position:fixed;inset:0;background:linear-gradient(160deg,rgba(2,8,16,0.85) 0%,rgba(90,15,15,0.2) 50%,rgba(2,8,16,0.9) 100%);z-index:-1}
      .main-container{padding:40px 20px;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center}
      .hero-card{background:linear-gradient(145deg,rgba(10,22,45,0.95),rgba(5,10,24,0.98));backdrop-filter:blur(20px);border:1px solid rgba(139,26,26,0.3);border-top:3px solid #c0392b;border-radius:20px;padding:32px;width:100%;max-width:500px;box-shadow:0 20px 60px rgba(0,0,0,0.8),0 0 40px rgba(139,26,26,0.15);text-align:center;margin-bottom:24px}
      .hero-title{font-size:1.8rem;font-weight:800;background:linear-gradient(135deg,#fff,#e05050);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:6px;letter-spacing:1px}
      .hero-subtitle{color:#a0b0c8;font-size:0.9rem;margin-bottom:20px}
      .status-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(139,26,26,0.2);border:1px solid rgba(139,26,26,0.4);border-radius:24px;padding:8px 20px;font-size:0.9rem;color:#e05050;font-weight:600;margin-bottom:20px}
      .status-badge::before{content:'';width:8px;height:8px;border-radius:50%;background:#c0392b;box-shadow:0 0 8px #c0392b;animation:blink 1.2s infinite}
      @keyframes blink{0%,100%{opacity:1}50%{opacity:0.3}}
      .features-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:18px 0}
      .feature-item{background:rgba(5,12,28,0.7);border:1px solid rgba(139,26,26,0.2);border-radius:10px;padding:12px;display:flex;align-items:center;gap:10px;transition:all 0.25s}
      .feature-item:hover{background:rgba(139,26,26,0.15);border-color:rgba(192,57,43,0.4);transform:translateY(-2px)}
      .feature-icon{font-size:1.3rem;color:#c0392b}
      .feature-label{font-size:0.82rem;color:#c8d4ec;font-weight:500}
      .feature-val{font-size:0.7rem;padding:2px 8px;border-radius:10px;font-weight:600;margin-top:2px}
      .feature-on{background:rgba(20,82,20,0.3);color:#4ada4a;border:1px solid rgba(30,122,30,0.4)}
      .feature-off{background:rgba(139,26,26,0.3);color:#f08080;border:1px solid rgba(192,57,43,0.4)}
      .links-card{background:linear-gradient(145deg,rgba(10,22,45,0.9),rgba(5,10,24,0.95));border:1px solid rgba(139,26,26,0.2);border-left:3px solid #8b1a1a;border-radius:14px;padding:22px;width:100%;max-width:500px;margin-bottom:18px}
      .links-title{color:#e05050;font-size:0.7rem;text-transform:uppercase;letter-spacing:2px;font-weight:700;margin-bottom:14px}
      .link-item{display:flex;align-items:center;gap:12px;padding:11px 14px;background:rgba(5,12,28,0.6);border:1px solid rgba(139,26,26,0.15);border-radius:9px;margin-bottom:8px;transition:all 0.2s;text-decoration:none;color:#c8d4ec}
      .link-item:hover{background:rgba(139,26,26,0.18);border-color:rgba(192,57,43,0.35);color:#fff;transform:translateX(-4px)}
      .link-item i{color:#c0392b;font-size:1rem;width:20px;text-align:center}
      .link-text{font-size:0.88rem}
      .link-text a{color:#e05050;text-decoration:none}
      .link-text a:hover{color:#e74c3c}
      @media(max-width:480px){.features-grid{grid-template-columns:1fr}.hero-card,.links-card{padding:22px}}

      /* Links grid inside hero-card */
      .links-grid{display:flex;flex-direction:column;gap:10px;margin:18px 0;text-align:right}
      .link-card{display:flex;align-items:center;gap:12px;padding:11px 14px;background:rgba(5,12,28,0.6);border:1px solid rgba(139,26,26,0.15);border-radius:10px;transition:all 0.2s}
      .link-card:hover{background:rgba(139,26,26,0.18);border-color:rgba(192,57,43,0.35);transform:translateX(4px)}
      .link-icon{color:#c0392b;font-size:1.1rem;width:22px;text-align:center;flex-shrink:0}
      .link-card .link-text{font-size:0.88rem;color:#c8d4ec}
      .link-card .link-text a{color:#e05050;text-decoration:none}
      .link-card .link-text a:hover{color:#e74c3c;text-decoration:underline}
      .subtitle{color:#a0b0c8;font-size:0.9rem;margin-bottom:18px;line-height:1.5}
      .footer-text{color:#7080a0;font-size:0.8rem;margin-top:16px}

      /* Main image - smaller */
      .main-image{max-width:140px;width:100%;height:auto;border-radius:12px;border:2px solid rgba(139,26,26,0.4);box-shadow:0 0 20px rgba(139,26,26,0.25);margin:14px auto 8px;display:block}
  </style>
        </head>

        <body>
            <div class="main-container">
                <div class="hero-card">
                    <h1>سيرفر كوكلي</h1>
                    <p class="subtitle">مرحبا بك إذا تريد شي بلخدمه <strong>كوكلي باشه </strong><br>اقوه مطور بتلي حجي </p>
                    <div class="links-grid">
                        <div class="link-card">
                            <div class="link-icon"><i class="bi bi-person-fill"></i></div>
                            <div class="link-text">للحصول على سيرفر خاص، تواصل مع <a href="https://t.me/x3_2r" target="_blank">@x3_2r</a></div>
                        </div>
                        <div class="link-card">
                            <div class="link-icon"><i class="bi bi-megaphone-fill"></i></div>
                            <div class="link-text">القناة الأساسية: <a href="https://t.me/x8_2r" target="_blank">x8_2r</a></div>
                        </div>
                        <div class="link-card">
                            <div class="link-icon"><i class="bi bi-megaphone-fill"></i></div>
                            <div class="link-text">القناة الثانية: <a href="https://t.me/x8_2r" target="_blank">x8_2r</a></div>
                        </div>
                        <div class="link-card">
                            <div class="link-icon"><i class="bi bi-chat-dots-fill"></i></div>
                            <div class="link-text">جروب الشات: <a href="https://t.me/+M6Oz1tZ_wkw1MTQ6" target="_blank">انضم للجروب</a></div>
                        </div>
                        <div class="link-card">
                            <div class="link-icon"><i class="bi bi-youtube"></i></div>
                            <div class="link-text">قناة اليوتيوب: <a href="https://t.me/x8_2r" target="_blank">كوك</a></div>
                        </div>
                        <div class="link-card">
                            <div class="link-icon"><i class="bi bi-robot"></i></div>
                            <div class="link-text">تواصل مع المطور: <a href="https://t.me/x8_2r" target="_blank">@x8_2r</a></div>
                        </div>
                    </div><img alt="سيرفر كوكلي" class="main-image" src="https://k.top4top.io/p_3794m5ofj0.png">
                    <p class="footer-text">ابني اتريد سيرفر راسلني ليش هيج مالك فكر</p>
                </div>
            </div>
        </body>

    </html>