<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
      body { background-color:#020810; font-family:'Poppins',sans-serif; min-height:100vh; display:flex; align-items:center; justify-content:center; margin:0; }
      .register-container { display:flex; justify-content:center; align-items:center; width:100%; padding:20px; }
      .card {
          background:linear-gradient(160deg,rgba(10,22,48,0.95),rgba(5,10,24,0.98)) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          border-top:3px solid #c0392b !important;
          border-radius:18px !important;
          box-shadow:0 20px 60px rgba(0,0,0,0.8),0 0 40px rgba(139,26,26,0.15);
          padding:40px; color:#fff; width:100%; max-width:460px; backdrop-filter:blur(20px);
      }
      .card-header { background:transparent !important; border-bottom:none !important; color:#fff !important; font-size:1.4rem; font-weight:700; text-align:center; }
      .card-header h2::after { content:''; display:block; width:50px; height:3px; background:linear-gradient(90deg,#8b1a1a,#e74c3c); border-radius:2px; margin:8px auto 0; }
      .card-body { padding:24px 20px; }
      label { color:#c0cce0; font-size:13px; display:block; text-align:left; margin-bottom:4px; }
      .form-control {
          background:rgba(5,12,28,0.8) !important;
          border:1px solid rgba(139,26,26,0.35) !important;
          color:#fff !important; border-radius:10px; padding:12px 18px;
      }
      .form-control:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      .btn-register {
          background:linear-gradient(135deg,#8b1a1a,#c0392b) !important;
          color:#fff !important; border:none !important; border-radius:10px;
          padding:13px; font-weight:700; width:100%;
          transition:all 0.25s; cursor:pointer;
          box-shadow:0 4px 16px rgba(192,57,43,0.35);
      }
      .btn-register:hover { background:linear-gradient(135deg,#c0392b,#e74c3c) !important; transform:translateY(-2px); }
      .login-link { color:#c0392b !important; }
      .login-link:hover { color:#e74c3c !important; }
      .input-icon { position:relative; }
      .input-icon i { position:absolute; right:14px; top:42px; color:rgba(255,255,255,0.5); cursor:pointer; }
  </style>

<div class="register-container">
    <div class="card shadow-sm">
        
        <div class="card-header">Register</div>
        
        <div class="card-body">
            <?= form_open() ?>

            <div class="form-group mb-3 input-icon" id="box-username">
                <label for="username">Username</label>
                <input type="text" class="form-control mt-2" name="username" id="username" placeholder="Your username" minlength="4" maxlength="24" value="<?= esc($username_value) ?>" required>
                <i class="bi bi-person-fill"></i>
            </div>
            
            <div class="form-group mb-3 input-icon hidden-field" id="box-fullname">
                <label for="fullname">Fullname</label>
                <input type="text" class="form-control mt-2" name="fullname" id="fullname" placeholder="Your fullname" minlength="4" maxlength="24" value="<?= esc($fullname_value) ?>">
                <i class="bi bi-person-badge-fill"></i>
            </div>
            
            <div class="form-group mb-3 input-icon hidden-field" id="box-password">
                <label for="password">Password</label>
                <input type="password" class="form-control mt-2" name="password" id="password" placeholder="Enter Password" minlength="6">
                <i class="bi bi-lock-fill toggle-password"></i>
            </div>
            
            <div class="form-group mb-3 input-icon hidden-field" id="box-password2">
                <label for="password2">Confirm Password</label>
                <input type="password" class="form-control mt-2" name="password2" id="password2" placeholder="Confirm password">
                <i class="bi bi-lock-fill toggle-password2"></i>
            </div>
            
            <div class="hidden-field" id="box-final">
                <div class="form-group mb-4 input-icon">
                    <label for="referral">Referral Code</label>
                    <input type="text" class="form-control mt-2" name="referral" id="referral" placeholder="Your Referral Code" value="<?= esc($referral_value) ?>" maxlength="25">
                    <i class="bi bi-gift-fill"></i>
                </div>
                
                <div class="form-group mt-4">
                    <button type="submit" class="btn-register">Register</button>
                </div>
            </div>
            
            <?= form_close() ?>
            
            <p class="text-center after-card mt-4">
                <small>Already have an account? <a href="<?= site_url('login') ?>">Login here</a></small>
            </p>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('js') ?>
<script>
    $(document).ready(function() {
        function setupToggle(currentInput, nextBox, minLen) {
            $(currentInput).on('input', function() {
                if ($(this).val().length >= minLen) {
                    $(nextBox).addClass('visible-field');
                } else {
                    $(nextBox).removeClass('visible-field');
                }
            });
        }

        setupToggle('#username', '#box-fullname', 3);
        setupToggle('#fullname', '#box-password', 3);
        setupToggle('#password', '#box-password2', 6);
        setupToggle('#password2', '#box-final', 6);

        $(document).on('click', '.toggle-password', function() {
            $(this).toggleClass("bi-lock-fill bi-unlock-fill");
            var input = $("#password");
            input.attr('type') === 'password' ? input.attr('type','text') : input.attr('type','password');
        });
        
        $(document).on('click', '.toggle-password2', function() {
            $(this).toggleClass("bi-lock-fill bi-unlock-fill");
            var input = $("#password2");
            input.attr('type') === 'password' ? input.attr('type','text') : input.attr('type','password');
        });
    });
</script>
<?= $this->endSection() ?>