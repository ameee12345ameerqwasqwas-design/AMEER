<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
      body {
          background-color:#020810;
          font-family:'Poppins',sans-serif;
          min-height:100vh; display:flex; align-items:center; justify-content:center;
          margin:0; padding:0;
      }
      .login-container { display:flex; justify-content:center; align-items:center; width:100%; padding:20px; }
      .card {
          background:linear-gradient(160deg,rgba(10,22,48,0.95),rgba(5,10,24,0.98)) !important;
          border:1px solid rgba(139,26,26,0.3) !important;
          border-top:3px solid #c0392b !important;
          border-radius:18px !important;
          box-shadow:0 20px 60px rgba(0,0,0,0.8),0 0 40px rgba(139,26,26,0.15);
          padding:40px; color:#fff; width:100%; max-width:440px;
          backdrop-filter:blur(20px);
      }
      .card-header { background:transparent !important; border-bottom:none !important; color:#fff !important; font-size:1.5rem; font-weight:700; text-align:center; padding-bottom:10px; }
      .card-header h2::after { content:''; display:block; width:50px; height:3px; background:linear-gradient(90deg,#8b1a1a,#e74c3c); border-radius:2px; margin:8px auto 0; }
      .card-body { padding:30px 20px; }
      .form-control {
          background:rgba(5,12,28,0.8) !important;
          border:1px solid rgba(139,26,26,0.35) !important;
          color:#fff !important; border-radius:10px; padding:12px 18px;
      }
      .form-control:focus { border-color:#c0392b !important; box-shadow:0 0 0 3px rgba(192,57,43,0.2) !important; }
      .form-control::placeholder { color:rgba(255,255,255,0.38) !important; }
      label { color:#c0cce0; font-size:13px; margin-bottom:4px; display:block; }
      .btn-login {
          background:linear-gradient(135deg,#8b1a1a,#c0392b) !important;
          color:#fff !important; border:none !important; border-radius:10px;
          padding:13px; font-weight:700; width:100%; font-size:1rem;
          transition:all 0.25s; cursor:pointer;
          box-shadow:0 4px 16px rgba(192,57,43,0.35);
      }
      .btn-login:hover { background:linear-gradient(135deg,#c0392b,#e74c3c) !important; transform:translateY(-2px); box-shadow:0 8px 24px rgba(192,57,43,0.5) !important; }
      .form-check-input { background:rgba(5,12,28,0.8) !important; border-color:rgba(139,26,26,0.5) !important; }
      .form-check-input:checked { background:#8b1a1a !important; border-color:#b02020 !important; }
      .form-check-label,.forgot-password { color:#c0cce0 !important; font-size:13px; }
      .forgot-password:hover { color:#e74c3c !important; }
      .register-link { color:#c0392b !important; }
      .register-link:hover { color:#e74c3c !important; }
      .after-card,.after-card a { color:#c0cce0 !important; }
      .after-card a { color:#c0392b !important; }
      .social-icon {
          display:inline-flex; justify-content:center; align-items:center;
          margin:0 12px; color:#fff; font-size:24px; width:52px; height:52px;
          border-radius:12px;
          background:rgba(139,26,26,0.2);
          border:1px solid rgba(139,26,26,0.4);
          transition:all 0.3s;
      }
      .social-icon:hover { background:#c0392b; transform:scale(1.1) translateY(-2px); box-shadow:0 6px 20px rgba(192,57,43,0.5); }
      .input-icon { position:relative; }
      .input-icon i { position:absolute; right:14px; top:42px; color:rgba(255,255,255,0.5); cursor:pointer; }
      .password-box { opacity:0; transform:translateY(10px); transition:all 0.3s ease; height:0; overflow:hidden; }
      .password-box.visible { opacity:1; transform:translateY(0); height:auto; overflow:visible; }
      .hidden { display:none; }
      @keyframes shake { 0%,100%{transform:translateX(0)} 20%,60%{transform:translateX(-5px)} 40%,80%{transform:translateX(5px)} }
      .shake { animation:shake 0.5s; }
  </style>
<?php 
$encoded_url = 'aHR0cHM6Ly90Lm1lL0hJTUEzNWJvdA==';
$decoded_url = base64_decode($encoded_url);
?>
<div class="login-container">
    <div class="card shadow-sm mb-5" id="loginBox">
        <div class="card-header">
            <h2>Welcome Back</h2>
        </div>
        <div class="card-body">
            <?= form_open() ?>
            <div class="form-group mb-4 input-icon">
                <label for="username">Username</label>
                <input type="text" class="form-control" name="username" id="username" aria-describedby="help-username" placeholder="Your username" required minlength="4" value="<?= esc($username_value) ?>">
                <i class="bi bi-person-fill"></i>
                <?php if (!empty($errors['username'])) : ?>
                    <small id="help-username" class="form-text text-warning"><?= esc($errors['username']) ?></small>
                <?php endif; ?>
            </div>
            
            <div class="password-box hidden" id="passwordBox">
                <div class="form-group mb-4 input-icon">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password" aria-describedby="help-password" placeholder="Your password" required minlength="6">
                    <i class="bi bi-eye-fill" id="togglePassword"></i>
                    <?php if (!empty($errors['password'])) : ?>
                        <small id="help-password" class="form-text text-warning"><?= esc($errors['password']) ?></small>
                    <?php endif; ?>
                </div>
                
                <input type="hidden" name="ip" value="<?= esc($user_agent) ?>" id="ip">
                
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" name="stay_log" id="stay_log" value="yes" <?= $stay_log_checked ?>>
                        <label class="form-check-label" for="stay_log" data-bs-toggle="tooltip" data-bs-placement="top" title="Keep session more than 30 minutes">
                            Remember me
                        </label>
                    </div>
                    <a href="<?= $decoded_url ?>" class="forgot-password" target="_blank" rel="noopener noreferrer">Forgot password?</a>
                </div>
            </div>
            
            <div class="form-group mb-3">
                <button type="submit" class="btn-login hidden" id="loginBtn">Login</button>
            </div>
            
            <div class="text-center mt-3">
                <p class="text-white mb-0">
                    Don't have an account? <a href="<?= site_url('register') ?>" class="register-link">Register</a>
                </p>
                <div class="social-icons">
                    <a href="https://t.me/beep51" target="_blank" class="social-icon telegram">
                        <i class="fab fa-telegram"></i>
                    </a>
                </div>
                <small class="px-auto p-2 rounded">
                    راسلني اذا اتريك شي :- 
                    <a href="<?= $decoded_url ?>" class="text-danger">@beep51</a>
                </small>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const usernameInput = document.getElementById('username');
        const passwordBox = document.getElementById('passwordBox');
        const loginBtn = document.getElementById('loginBtn');
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        const loginBox = document.getElementById('loginBox');

        usernameInput.addEventListener('input', function() {
            if (this.value.length >= 3) {
                passwordBox.classList.remove('hidden');
                setTimeout(() => {
                    passwordBox.classList.add('visible');
                }, 10);
            } else if (this.value.length < 3 && !passwordBox.classList.contains('hidden')) {
                passwordBox.classList.remove('visible');
                setTimeout(() => {
                    passwordBox.classList.add('hidden');
                    loginBtn.classList.add('hidden');
                }, 300);
            }
        });

        passwordInput.addEventListener('input', function() {
            if (this.value.length >= 1) {
                loginBtn.classList.remove('hidden');
                setTimeout(() => {
                    loginBtn.style.opacity = '1';
                    loginBtn.style.transform = 'translateY(0)';
                }, 10);
            } else {
                loginBtn.style.opacity = '0';
                loginBtn.style.transform = 'translateY(10px)';
                setTimeout(() => {
                    loginBtn.classList.add('hidden');
                }, 300);
            }
        });

        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('bi-eye-fill');
            this.classList.toggle('bi-eye-slash-fill');
        });

        usernameInput.addEventListener('animationend', function() {
            this.classList.remove('shake');
        });

        passwordInput.addEventListener('animationend', function() {
            this.classList.remove('shake');
        });

        setInterval(() => {
            loginBox.style.animation = 'float 16s ease-in-out infinite';
        }, 0);
    });
</script>

<?= $this->endSection() ?>