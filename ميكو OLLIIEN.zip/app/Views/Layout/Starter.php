<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Kanit:wght@300;400;500;700;900&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!-- Custom CSS -->
    <?= link_tag('assets/css/natacode.css') ?>
    <link rel="icon" type="image/x-icon" href="<?= base_url('assets/favicon.ico') ?>">


    <title><?= BASE_NAME ?> - <?= isset($title) ? $title : 'Panel' ?></title>
    <?= $this->renderSection('css') ?>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
</head>

<style>
    body {
        font-family: 'Poppins', sans-serif !important;
        margin: 0;
        padding: 0;
        background-color: #080f28;
        overflow-x: hidden;
        position: relative;
    }

    /* Animated Background */
    body::before {
        content: "";
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url('<?= base_url('assets/images/bmw_bg.png') ?>') center/cover no-repeat;
        z-index: -2;
        animation: backgroundPulse 20s infinite alternate;
    }

    body::after {
        content: "";
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: radial-gradient(circle, rgba(13, 27, 66, 0.3) 0%, rgba(8, 15, 42, 0.7) 100%);
        z-index: -1;
        animation: gradientShift 15s infinite alternate;
    }

    .particles {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: -1;
    }

    .particle {
        position: absolute;
        width: 5px;
        height: 5px;
        background-color: rgba(255, 255, 255, 0.5);
        border-radius: 50%;
        animation: float 15s infinite linear;
    }

    @keyframes backgroundPulse {
        0%   { transform: scale(1); }
        100% { transform: scale(1.1); }
    }

    @keyframes gradientShift {
        0%   { opacity: 0.7; }
        50%  { opacity: 0.5; }
        100% { opacity: 0.7; }
    }

    @keyframes float {
        0%   { transform: translateY(0) translateX(0); opacity: 0; }
        10%  { opacity: 1; }
        90%  { opacity: 1; }
        100% { transform: translateY(-100vh) translateX(100px); opacity: 0; }
    }

    .container {
        position: relative;
        z-index: 1;
    }

    .hacks {
        position: relative;
        display: inline-block;
        width: 80%;
        height: 20px;
        float: left;
        margin: 5%;
    }

    .switch {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 20px;
        float: right;
        margin: 5px;
    }

    .switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }

    .slider {
        position: absolute;
        cursor: pointer;
        inset: 0;
        background-color: rgba(204, 204, 204, 0.3);
        transition: .4s;
        border-radius: 34px;
    }

    .slider:before {
        position: absolute;
        content: "";
        height: 12px;
        width: 12px;
        left: 4px;
        bottom: 4px;
        background-color: #fff;
        transition: .4s;
        border-radius: 50%;
    }

    input:checked + .slider {
        background-color: #9b1f1f;
    }

    input:focus + .slider {
        box-shadow: 0 0 3px #9b1f1f;
    }

    input:checked + .slider:before {
        transform: translateX(20px);
    }

    footer {
        background-color: rgba(13, 27, 66, 0.7) !important;
        backdrop-filter: blur(10px);
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        color: #fff !important;
        width: 95%;
        margin: 0 auto;
        padding: 10px 20px;
        border-radius: 20px;
        text-align: center;
    }
</style>


<body>
    <!-- Start menu -->
    <?php 
        $uri = service('uri'); 
        $current_page = $uri->getSegment(1);
    ?>
    <?php if ($current_page != 'login' && $current_page != 'register' && $current_page != '') :  ?>
        <?= $this->include('Layout/Header') ?>
    <?php endif; ?>
    <!-- End of menu -->


    
    <!-- Particles container -->
    <div class="particles" id="particles"></div>
    
    <main>
        <div class="container p-6 py-4 mb-2">
            <!-- Start content -->
            <?= $this->renderSection('content') ?>
            <!-- End of content -->
        </div>
    </main>
    <!--
    <footer class="py-3 text-white">
        <div class="container">
            <small class="text-warning">&copy; <?= date('Y') ?> - <?= BASE_NAME ?></small>
        </div>
    </footer>
     -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.0/sweetalert2.all.min.js" integrity="sha512-0UUEaq/z58JSHpPgPv8bvdhHFRswZzxJUT9y+Kld5janc9EWgGEVGfWV1hXvIvAJ8MmsR5d4XV9lsuA90xXqUQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


    <?= $this->renderSection('js') ?>
    
    

  
  <style>
  @keyframes particleRise {
    0%   { transform:translateY(0) translateX(0);    opacity:0; }
    5%   { opacity:1; }
    90%  { opacity:0.5; }
    100% { transform:translateY(-105vh) translateX(var(--dx,40px)); opacity:0; }
  }
  @keyframes twinkle {
    0%   { opacity:0.1; transform:scale(0.8); }
    100% { opacity:0.9; transform:scale(1.8); box-shadow:0 0 10px 4px rgba(192,57,43,0.7); }
  }
  </style>
</body>

</html>