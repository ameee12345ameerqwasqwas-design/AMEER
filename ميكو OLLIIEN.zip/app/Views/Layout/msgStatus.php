<?php if (session()->getFlashdata('msgDanger')) : ?>
    <div class="alert custom-alert danger-alert" role="alert">
        <div class="alert-icon"><i class="bi bi-exclamation-triangle-fill"></i></div>
        <div class="alert-content"><?= session()->getFlashdata('msgDanger') ?></div>
    </div>
<?php elseif (session()->getFlashdata('msgSuccess')) : ?>
    <div class="alert custom-alert success-alert" role="alert">
        <div class="alert-icon"><i class="bi bi-check-circle-fill"></i></div>
        <div class="alert-content"><?= session()->getFlashdata('msgSuccess') ?></div>
    </div>
<?php elseif (session()->getFlashdata('msgWarning')) : ?>
    <div class="alert custom-alert warning-alert" role="alert">
        <div class="alert-icon"><i class="bi bi-exclamation-circle-fill"></i></div>
        <div class="alert-content"><?= session()->getFlashdata('msgWarning') ?></div>
    </div>
<?php else : ?>
    <?php if (session()->has('userid')) : ?>
        <?php if (isset($messages)) : ?>
            <div class="alert custom-alert <?= $messages[1] ?>-alert" role="alert">
                <div class="alert-icon">
                    <?php if ($messages[1] == 'primary'): ?>
                        <i class="bi bi-info-circle-fill"></i>
                    <?php elseif ($messages[1] == 'success'): ?>
                        <i class="bi bi-check-circle-fill"></i>
                    <?php elseif ($messages[1] == 'danger'): ?>
                        <i class="bi bi-exclamation-triangle-fill"></i>
                    <?php elseif ($messages[1] == 'warning'): ?>
                        <i class="bi bi-exclamation-circle-fill"></i>
                    <?php else: ?>
                        <i class="bi bi-bell-fill"></i>
                    <?php endif; ?>
                </div>
                <div class="alert-content"><?= $messages[0] ?></div>
            </div>
        <?php else : ?>
            <div class="alert custom-alert primary-alert" role="alert">
                <div class="alert-icon"><i class="bi bi-person-check-fill"></i></div>
                <div class="alert-content">Welcome back, <span class="fw-bold"><?= getName($user) ?></span>!</div>
            </div>
        <?php endif; ?>
    <?php else : ?>
        <div class="alert custom-alert primary-alert" role="alert">
            <div class="alert-icon"><i class="bi bi-person-fill"></i></div>
            <div class="alert-content">Welcome Stranger</div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
<?php endif; ?>

<style>
  .custom-alert {
    display:flex; align-items:center;
    padding:14px 18px; border-radius:10px;
    margin:16px auto; max-width:520px; width:92%;
    background:linear-gradient(135deg, rgba(7,14,32,0.92), rgba(10,22,45,0.88));
    backdrop-filter:blur(12px);
    box-shadow:0 4px 20px rgba(0,0,0,0.5);
    border:1px solid rgba(139,26,26,0.2);
    border-left:4px solid var(--r4,#b02020);
    color:#e8e8e8;
    position:relative; overflow:hidden;
    animation:alertIn 0.4s ease-out forwards;
  }
  @keyframes alertIn { from{opacity:0;transform:translateY(-12px)} to{opacity:1;transform:translateY(0)} }
  .alert-icon {
    margin-right:14px; width:34px; height:34px; border-radius:8px;
    background:rgba(139,26,26,0.2); display:flex; align-items:center; justify-content:center;
    font-size:1.1rem; flex-shrink:0;
  }
  .alert-content { flex:1; font-weight:500; font-size:0.92rem; }
  .primary-alert { border-left-color:#b02020; }
  .primary-alert .alert-icon { color:#e05050; }
  .success-alert { border-left-color:#1e7a1e; background:linear-gradient(135deg,rgba(7,14,32,0.92),rgba(10,30,10,0.88)) !important; }
  .success-alert .alert-icon { color:#4ada4a; background:rgba(30,122,30,0.2); }
  .danger-alert  { border-left-color:#c0392b; }
  .danger-alert .alert-icon  { color:#e74c3c; }
  .warning-alert { border-left-color:#c09000; background:linear-gradient(135deg,rgba(7,14,32,0.92),rgba(20,16,5,0.88)) !important; }
  .warning-alert .alert-icon { color:#f0c030; background:rgba(120,80,0,0.2); }
  .custom-alert .btn-close { filter:invert(1) grayscale(100%) brightness(200%); opacity:0.6; }
  .custom-alert .btn-close:hover { opacity:1; }
  </style>
