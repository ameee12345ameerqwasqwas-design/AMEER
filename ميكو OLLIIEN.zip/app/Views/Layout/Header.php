<?php $uri = service('uri'); ?>

<style>
  :root {
    --n1:#020810; --n2:#050e1e; --n3:#07142a;
    --r3:#8b1a1a; --r4:#b02020; --r5:#c0392b;
    --glow:rgba(139,26,26,0.4);
  }
  * { box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
  body { margin:0; padding:0; overflow-x:hidden; font-family:'Poppins',sans-serif; }

  .menu-button {
    position:fixed; right:22px; bottom:22px;
    width:56px; height:56px; border-radius:14px;
    background:linear-gradient(135deg,#7a1515,#c0392b);
    border:none;
    display:flex; flex-direction:column; align-items:center; justify-content:center; gap:5px;
    cursor:pointer; z-index:1000;
    box-shadow:0 4px 20px rgba(192,57,43,0.5);
    transition:all 0.3s;
  }
  .menu-button span { display:block; width:22px; height:2px; background:#fff; border-radius:1px; transition:all 0.3s; }
  .menu-button:hover { transform:scale(1.08); box-shadow:0 6px 28px rgba(192,57,43,0.7); }
  .menu-button.active { background:linear-gradient(135deg,#c0392b,#e74c3c); border-radius:50%; }
  .menu-button.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
  .menu-button.active span:nth-child(2) { opacity:0; }
  .menu-button.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

  .sidebar-overlay {
    position:fixed; inset:0;
    background:rgba(2,8,16,0.6);
    backdrop-filter:blur(0px);
    opacity:0; visibility:hidden;
    transition:all 0.4s; z-index:999; pointer-events:none;
  }
  .sidebar-overlay.active {
    opacity:1; visibility:visible; pointer-events:auto;
    backdrop-filter:blur(6px);
  }

  .sidebar {
    position:fixed; top:0; bottom:0; right:-100%;
    width:300px;
    background:linear-gradient(180deg, rgba(5,10,22,0.98) 0%, rgba(8,14,28,0.99) 100%);
    border-left:1px solid rgba(139,26,26,0.4);
    box-shadow:-8px 0 40px rgba(0,0,0,0.8), inset -1px 0 0 rgba(139,26,26,0.2);
    z-index:1000; display:flex; flex-direction:column;
    transition:right 0.4s cubic-bezier(0.19,1,0.22,1);
  }
  .sidebar.active { right:0; }
  .sidebar::before {
    content:'';
    position:absolute; top:0; left:0; bottom:0; width:3px;
    background:linear-gradient(180deg, transparent, var(--r5), transparent);
    opacity:0.6;
  }

  .sidebar-inner { flex:1; overflow-y:auto; padding:22px 18px; }
  .sidebar-inner::-webkit-scrollbar { width:3px; }
  .sidebar-inner::-webkit-scrollbar-thumb { background:var(--r3); border-radius:2px; }

  .sidebar-header {
    display:flex; align-items:center; justify-content:space-between;
    margin-bottom:22px; padding-bottom:14px;
    border-bottom:1px solid rgba(139,26,26,0.25);
  }
  .brand-wrapper { display:flex; align-items:center; gap:10px; }
  .brand-logo { width:42px; height:42px; border-radius:10px; border:2px solid rgba(139,26,26,0.5); padding:2px; }
  .brand-name { font-size:1.2rem; font-weight:700; color:#fff; letter-spacing:0.5px; }
  .brand-name span { color:var(--r5); }

  .close-sidebar {
    width:32px; height:32px; border-radius:8px;
    background:rgba(139,26,26,0.15); border:1px solid rgba(139,26,26,0.3);
    color:#d0d0d0; cursor:pointer; transition:all 0.2s;
    display:flex; align-items:center; justify-content:center;
  }
  .close-sidebar:hover { background:var(--r3); color:#fff; transform:rotate(90deg); }

  .user-profile-card {
    display:flex; align-items:center; gap:12px;
    background:rgba(10,22,45,0.5);
    border:1px solid rgba(139,26,26,0.2);
    border-left:3px solid var(--r3);
    border-radius:12px; padding:16px;
    margin-bottom:20px;
  }
  .avatar-icon {
    width:46px; height:46px; border-radius:10px;
    background:linear-gradient(135deg,var(--r3),var(--r5));
    display:flex; align-items:center; justify-content:center;
    color:#fff; font-size:1.1rem; flex-shrink:0;
    box-shadow:0 4px 12px rgba(139,26,26,0.4);
  }

  .menu-section-title {
    font-size:0.7rem; color:var(--r5);
    text-transform:uppercase; letter-spacing:2px;
    margin:18px 0 8px 8px; font-weight:700; opacity:0.9;
  }

  .sidebar a {
    display:flex; align-items:center;
    padding:12px 14px; color:#c0cce0;
    text-decoration:none; border-radius:10px;
    margin-bottom:4px; border:1px solid transparent;
    font-size:0.9rem; transition:all 0.2s;
    position:relative;
  }
  .sidebar a i { font-size:1rem; width:22px; text-align:center; margin-right:12px; transition:all 0.2s; }
  .sidebar a:hover {
    background:rgba(139,26,26,0.15);
    color:#fff; border-color:rgba(139,26,26,0.25);
    transform:translateX(-4px);
  }
  .sidebar a:hover i { color:var(--r5); }
  .sidebar a.active {
    background:linear-gradient(90deg,rgba(139,26,26,0.3),rgba(10,22,45,0.2));
    border:1px solid rgba(139,26,26,0.4);
    color:#fff;
    box-shadow:0 2px 12px rgba(139,26,26,0.2);
  }
  .sidebar a.active i { color:var(--r5); }
  .sidebar a.active::before {
    content:''; position:absolute; right:0; top:20%; bottom:20%;
    width:3px; background:var(--r5);
    border-radius:2px 0 0 2px;
  }

  .sidebar-divider {
    height:1px;
    background:linear-gradient(90deg,transparent,rgba(139,26,26,0.3),transparent);
    margin:14px 0;
  }

  .sidebar-footer { margin-top:24px; padding-top:16px; border-top:1px solid rgba(139,26,26,0.2); }
  .sidebar-footer a {
    background:linear-gradient(135deg,rgba(192,57,43,0.12),rgba(5,14,30,0.5)) !important;
    border:1px solid rgba(139,26,26,0.3) !important;
    color:#e08080 !important;
  }
  .sidebar-footer a:hover {
    background:linear-gradient(135deg,rgba(192,57,43,0.3),rgba(5,14,30,0.7)) !important;
    color:#fff !important;
  }

  @media(max-width:768px) {
    .sidebar { width:82%; max-width:300px; }
  }
  </style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<?php if ($uri->getSegment(1) != 'login') : ?>
    <div class="menu-button" id="menuButton" aria-label="Toggle menu" data-sound="trigger">
        <span></span><span></span><span></span>
    </div>
<?php endif; ?>

<nav class="sidebar" id="sidebar" role="navigation" aria-label="Main navigation">
    <div class="sidebar-inner">
        <div class="sidebar-header">
            <div class="brand-wrapper">
                <img src="/assets/favicon.ico" alt="<?= BASE_NAME ?> Logo" class="brand-logo" loading="lazy">
                <span class="brand-name"><?= BASE_NAME ?></span>
            </div>
            <button class="close-sidebar" id="closeSidebar" aria-label="Close menu" data-sound="trigger">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <?php if (session()->has('userid')) : ?>
            <div class="user-profile-card">
                <div class="avatar-icon" aria-hidden="true">
                    <i class="fas fa-user-secret"></i>
                </div>
                <div>
                    <h4 style="margin:0;color:white;font-size:1.1rem;font-weight:600;">
                        <?= getName($user) ?>
                    </h4>
                    <span style="font-size:0.75rem;padding:4px 12px;border-radius:50px;background:rgba(192, 57, 43, 0.2);color:#c0392b;display:inline-block;margin-top:6px;border:1px solid rgba(192, 57, 43, 0.3);">
                        <?= getLevel($user->level) ?>
                    </span>
                    <span style="font-size:0.75rem;padding:4px 12px;border-radius:50px;background:rgba(255, 193, 7, 0.2);color:#ffc107;display:inline-block;margin-top:6px;border:1px solid rgba(255, 193, 7, 0.3); margin-left:5px;">
                        <i class="bi bi-wallet"></i> <?= $user->saldo ?> 
                    </span>
                </div>
            </div>

            <span class="menu-section-title">Main Menu</span>
            <a href="<?= site_url('dashboard') ?>" 
               class="<?= $uri->getSegment(1) == 'dashboard' ? 'active' : '' ?>" 
               data-sound="hover">
                <i class="fas fa-home"></i><span>Home</span>
            </a>
            <a href="<?= site_url('keys') ?>" 
               class="<?= ($uri->getSegment(1) == 'keys' && $uri->getSegment(2) == '') ? 'active' : '' ?>" 
               data-sound="hover">
                <i class="fas fa-key"></i><span>Keys</span>
            </a>
            <a href="<?= site_url('keys/generate') ?>" 
               class="<?= $uri->getSegment(2) == 'generate' ? 'active' : '' ?>" 
               data-sound="hover">
                <i class="fas fa-plus-circle"></i><span>Generate</span>
            </a>

            <div class="sidebar-divider"></div>

            <span class="menu-section-title">System</span>
            <a href="<?= site_url('settings') ?>" 
               class="<?= $uri->getSegment(1) == 'settings' ? 'active' : '' ?>" 
               data-sound="hover">
                <i class="fas fa-cog"></i><span>Settings</span>
            </a>

            <?php if ($user->level == 1) : ?>
                <a href="<?= site_url('Server') ?>" 
                   class="<?= $uri->getSegment(1) == 'Server' ? 'active' : '' ?>" 
                   data-sound="hover">
                    <i class="fas fa-server"></i><span>Online System</span>
                </a>

                <a href="<?= site_url('lib') ?>" 
                   class="<?= $uri->getSegment(1) == 'lib' ? 'active' : '' ?>" 
                   data-sound="hover">
                    <i class="fas fa-folder-open"></i><span>File Manager</span>
                </a>
                <a href="<?= site_url('bots') ?>" 
                    class="<?= $uri->getSegment(1) == 'bots' ? 'active' : '' ?>" 
                    data-sound="hover">
                    <i class="fas fa-robot"></i><span>Bots</span>
                </a>
                
                <a href="<?= site_url('panelsettings') ?>" 
                   class="<?= $uri->getSegment(1) == 'panelsettings' ? 'active' : '' ?>" 
                   data-sound="hover">
                    <i class="fas fa-cogs"></i><span>Panel Settings</span>
                </a>

                <a href="<?= site_url('admin/manage-users') ?>" 
                   class="<?= ($uri->getSegment(1) == 'admin' && $uri->getSegment(2) == 'manage-users') ? 'active' : '' ?>" 
                   data-sound="hover">
                    <i class="fas fa-users"></i><span>Manage Users</span>
                </a>

                <a href="<?= site_url('admin/create-referral') ?>" 
                   class="<?= ($uri->getSegment(1) == 'admin' && $uri->getSegment(2) == 'create-referral') ? 'active' : '' ?>" 
                   data-sound="hover">
                    <i class="fas fa-user-plus"></i><span>Create Referral</span>
                </a>
            <?php endif; ?>


              <div class="sidebar-footer">
                <a href="<?= site_url('logout') ?>" data-sound="out">
                    <i class="fas fa-sign-out-alt"></i><span>Logout</span>
                </a>
            </div>
        <?php endif; ?>
    </div>
</nav>

<script>

const AudioEngine = {
    ctx: null,
    masterGain: null,
    init() {
        if (!this.ctx) {
            this.ctx = new (window.AudioContext || window.webkitAudioContext)();
            this.masterGain = this.ctx.createGain();
            this.masterGain.connect(this.ctx.destination);
            this.masterGain.gain.value = 0.1; 
        }
        if (this.ctx.state === 'suspended') this.ctx.resume();
    },
    play(freq, type = 'sine', duration = 0.1, vol = 1) {
        try {
            this.init();
            const t = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const g = this.ctx.createGain();
            osc.type = type;
            osc.frequency.setValueAtTime(freq, t);
            g.gain.setValueAtTime(0, t);
            g.gain.linearRampToValueAtTime(vol, t + 0.01);
            g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
            osc.connect(g);
            g.connect(this.masterGain);
            osc.start(t);
            osc.stop(t + duration);
            osc.onended = () => { osc.disconnect(); g.disconnect(); };
        } catch(e) {}
    },
    trigger(name) {
        switch(name) {
            case 'hover': this.play(800, 'sine', 0.05, 0.2); break;
            case 'trigger': this.play(400, 'sine', 0.1, 0.4); break;
            case 'out': this.play(150, 'sawtooth', 0.4, 0.3); break;
        }
    }
};

let isSidebarOpen = false;
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebarOverlay');
const menuButton = document.getElementById('menuButton');
const closeButton = document.getElementById('closeSidebar');

function toggleSidebar() {
    isSidebarOpen = !isSidebarOpen;
    
    if (isSidebarOpen) {
        AudioEngine.trigger('trigger'); 
        sidebar.classList.add('active');
        overlay.classList.add('active');
        if (menuButton) menuButton.classList.add('active');
        
        document.body.style.overflow = 'hidden';
        
        setTimeout(() => {
            const items = document.querySelectorAll('.sidebar a, .user-profile-card');
            items.forEach((item, index) => {
                item.style.opacity = '0';
                item.style.transform = 'translateX(20px)';
                
                setTimeout(() => {
                    item.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'translateX(0)';
                }, index * 40);
            });
        }, 100);
        
    } else {
        AudioEngine.trigger('trigger'); 
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
        if (menuButton) menuButton.classList.remove('active');
        
        document.body.style.overflow = '';
        
        setTimeout(() => {
            const items = document.querySelectorAll('.sidebar a, .user-profile-card');
            items.forEach(item => {
                item.style.opacity = '';
                item.style.transform = '';
                item.style.transition = '';
            });
        }, 300);
    }
}

function initSidebar() {
    if (menuButton) menuButton.addEventListener('click', toggleSidebar);
    if (closeButton) closeButton.addEventListener('click', toggleSidebar);
    if (overlay) overlay.addEventListener('click', toggleSidebar);
    
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && isSidebarOpen) toggleSidebar();
    });
    
    if ('ontouchstart' in window) {
        let startX = 0;
        sidebar.addEventListener('touchstart', (e) => { startX = e.touches[0].clientX; }, { passive: true });
        sidebar.addEventListener('touchend', (e) => {
            if (!isSidebarOpen) return;
            const endX = e.changedTouches[0].clientX;
            if (startX - endX > 80) toggleSidebar(); 
        }, { passive: true });
        
        document.querySelectorAll('.sidebar a').forEach(link => {
            link.addEventListener('click', () => {
                if (window.innerWidth <= 768) setTimeout(toggleSidebar, 150);
            });
        });
    }
    
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768 && isSidebarOpen) toggleSidebar();
    });
}

document.querySelectorAll('[data-sound]').forEach(el => {
    el.addEventListener('mouseenter', () => AudioEngine.trigger(el.dataset.sound));
});

document.addEventListener('DOMContentLoaded', () => {
    initSidebar();
});
const encoded = "aHR0cHM6Ly90Lm1lL0hJTUEzNWJvdA==";
document.getElementById("link1").href = atob(encoded);
</script>