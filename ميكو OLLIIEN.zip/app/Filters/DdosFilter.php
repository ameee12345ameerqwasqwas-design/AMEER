<?php
  namespace App\Filters;

  use CodeIgniter\Filters\FilterInterface;
  use CodeIgniter\HTTP\RequestInterface;
  use CodeIgniter\HTTP\ResponseInterface;

  /**
   * DDoS / Rate-Limit Filter
   * - 100 requests / 60 seconds per IP  → 429 (Too Many Requests)
   * - 25 requests / 5 seconds burst      → 429 (burst block)
   * - Blocked IPs auto-unban after 5 min
   * - Cleanup runs every ~60 reqs (random) to avoid stale files
   */
  class DdosFilter implements FilterInterface
  {
      // Config
      private int   $maxPerMin    = 100;   // requests per 60s
      private int   $maxBurst     = 25;    // requests per 5s
      private int   $banDuration  = 300;   // 5 minutes ban
      private int   $windowMin    = 60;    // 1-minute window
      private int   $windowBurst  = 5;     // 5-second burst window
      private string $cacheDir;

      // Whitelisted IPs (always allow)
      private array $whitelist = ['127.0.0.1', '::1'];

      public function __construct()
      {
          $this->cacheDir = WRITEPATH . 'ddos_cache' . DIRECTORY_SEPARATOR;
          if (!is_dir($this->cacheDir)) {
              mkdir($this->cacheDir, 0755, true);
          }
          // Random cleanup to avoid stale ban files
          if (random_int(1, 80) === 1) {
              $this->cleanup();
          }
      }

      public function before(RequestInterface $request, $arguments = null)
      {
          $ip = $this->getClientIp($request);

          // Skip whitelisted
          if (in_array($ip, $this->whitelist, true)) {
              return null;
          }

          $ipKey = hash('sha256', $ip);

          // ── 1. Check active ban ──
          $banFile = $this->cacheDir . 'ban_' . $ipKey . '.json';
          if (file_exists($banFile)) {
              $ban = json_decode(file_get_contents($banFile), true);
              if ($ban && time() < $ban['until']) {
                  $retryAfter = $ban['until'] - time();
                  return $this->block($request, $retryAfter,
                      'Your IP has been temporarily blocked due to excessive requests. Try again in '
                      . ceil($retryAfter / 60) . ' minute(s).'
                  );
              }
              // Ban expired – remove it
              @unlink($banFile);
          }

          $now = time();

          // ── 2. Sliding window (per-minute) ──
          $minFile = $this->cacheDir . 'min_' . $ipKey . '.json';
          $minData = $this->loadData($minFile);
          $minData = array_filter($minData, fn($t) => $t > $now - $this->windowMin);
          $minData[] = $now;

          if (count($minData) > $this->maxPerMin) {
              $this->ban($banFile, $now);
              return $this->block($request, $this->banDuration,
                  'Rate limit exceeded. IP banned for ' . ($this->banDuration / 60) . ' minutes.'
              );
          }
          $this->saveData($minFile, array_values($minData));

          // ── 3. Burst window (5-second) ──
          $burstFile = $this->cacheDir . 'burst_' . $ipKey . '.json';
          $burstData = $this->loadData($burstFile);
          $burstData = array_filter($burstData, fn($t) => $t > $now - $this->windowBurst);
          $burstData[] = $now;

          if (count($burstData) > $this->maxBurst) {
              $this->ban($banFile, $now);
              return $this->block($request, $this->banDuration,
                  'Burst rate limit exceeded. IP banned for ' . ($this->banDuration / 60) . ' minutes.'
              );
          }
          $this->saveData($burstFile, array_values($burstData));

          return null;
      }

      public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
      {
          return $response;
      }

      // ── Helpers ──

      private function getClientIp(RequestInterface $request): string
      {
          foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR'] as $header) {
              $val = $_SERVER[$header] ?? '';
              if ($val) {
                  return trim(explode(',', $val)[0]);
              }
          }
          return $request->getIPAddress();
      }

      private function ban(string $banFile, int $now): void
      {
          file_put_contents($banFile, json_encode([
              'since' => $now,
              'until' => $now + $this->banDuration,
          ]));
      }

      private function block(RequestInterface $request, int $retryAfter, string $msg): ResponseInterface
      {
          $response = service('response');
          $response->setStatusCode(429);
          $response->setHeader('Retry-After', (string)$retryAfter);
          $response->setHeader('X-RateLimit-Limit', (string)$this->maxPerMin);
          $response->setHeader('Content-Type', 'text/html; charset=utf-8');
          $response->setBody($this->blockPage($msg, $retryAfter));
          return $response;
      }

      private function loadData(string $file): array
      {
          if (!file_exists($file)) return [];
          $data = json_decode(file_get_contents($file), true);
          return is_array($data) ? $data : [];
      }

      private function saveData(string $file, array $data): void
      {
          file_put_contents($file, json_encode($data));
      }

      private function cleanup(): void
      {
          $files = glob($this->cacheDir . '*.json') ?: [];
          $now   = time();
          foreach ($files as $f) {
              // Remove old rate files (>120s old)
              if (basename($f, '.json') !== ltrim(basename($f, '.json'), 'ban_')
                  && filemtime($f) < $now - 120) {
                  @unlink($f);
              }
              // Remove expired bans
              if (str_starts_with(basename($f), 'ban_')) {
                  $data = json_decode(file_get_contents($f), true);
                  if ($data && $data['until'] < $now) {
                      @unlink($f);
                  }
              }
          }
      }

      /** Beautiful block page */
      private function blockPage(string $msg, int $retryAfter): string
      {
          $min = ceil($retryAfter / 60);
          return <<<HTML
  <!DOCTYPE html>
  <html dir="rtl" lang="ar">
  <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>429 – محظور مؤقت</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:'Poppins',sans-serif;background:#020810;color:#fff;min-height:100vh;
         display:flex;align-items:center;justify-content:center;
         background:radial-gradient(circle at 30% 30%,rgba(139,26,26,0.15),transparent 60%),
                    radial-gradient(circle at 70% 80%,rgba(192,57,43,0.1),transparent 50%), #020810;}
    .card{background:linear-gradient(145deg,rgba(10,22,45,0.95),rgba(5,10,24,0.98));
          border:1px solid rgba(139,26,26,0.3);border-top:3px solid #c0392b;
          border-radius:20px;padding:48px 40px;text-align:center;max-width:500px;width:90%;
          box-shadow:0 20px 60px rgba(0,0,0,0.8),0 0 40px rgba(139,26,26,0.12);}
    .icon{font-size:4rem;margin-bottom:16px;filter:drop-shadow(0 0 16px rgba(192,57,43,0.6));}
    h1{font-size:5rem;font-weight:900;color:#c0392b;text-shadow:0 0 30px rgba(192,57,43,0.5);
       line-height:1;margin-bottom:8px;}
    h2{font-size:1.3rem;color:#fff;margin-bottom:14px;font-weight:700;}
    p{color:#a0b0c8;margin-bottom:24px;line-height:1.7;font-size:0.92rem;}
    .timer{background:rgba(139,26,26,0.15);border:1px solid rgba(139,26,26,0.35);
           border-radius:12px;padding:16px 24px;display:inline-block;margin-bottom:24px;}
    .timer span{font-size:2.2rem;font-weight:800;color:#e74c3c;display:block;}
    .timer small{color:#a0b0c8;font-size:0.8rem;}
    .btn{display:inline-block;margin-top:8px;padding:11px 32px;border-radius:10px;
         background:linear-gradient(135deg,#8b1a1a,#c0392b);color:#fff;
         text-decoration:none;font-weight:700;font-size:0.9rem;
         box-shadow:0 4px 16px rgba(192,57,43,0.35);}
  </style>
  </head>
  <body>
  <div class="card">
    <div class="icon">🛡️</div>
    <h1>429</h1>
    <h2>طلبات كثيرة جداً</h2>
    <p>$msg</p>
    <div class="timer">
      <span id="cd">{$retryAfter}</span>
      <small>ثانية متبقية</small>
    </div>
    <br>
    <a href="/" class="btn">↩ العودة للرئيسية</a>
  </div>
  <script>
  let s = {$retryAfter};
  const el = document.getElementById('cd');
  setInterval(()=>{ s = Math.max(0,s-1); el.textContent = s; if(s===0) location.reload(); }, 1000);
  </script>
  </body></html>
  HTML;
      }
  }
  