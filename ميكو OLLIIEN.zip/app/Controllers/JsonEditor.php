<?php
  namespace App\Controllers;

  use CodeIgniter\Controller;

  class JsonEditor extends BaseController
  {
      public function index()
      {
          return view('JsonEditor/index');
      }
  }
  